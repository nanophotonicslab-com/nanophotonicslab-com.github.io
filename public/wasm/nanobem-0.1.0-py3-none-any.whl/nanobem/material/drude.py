"""Drude model for metal permittivity.

ε(ω) = ε∞ - ωp² / (ω² + iγω)

where ε∞ is the background permittivity (interband transitions),
ωp is the plasma frequency, and γ is the damping rate.
All frequencies in eV.

Reference: Bohren & Huffman, Chapter 9.
"""


def drude_permittivity(
    omega: float, omega_p: float, gamma: float, eps_inf: float = 1.0
) -> complex:
    """Compute Drude permittivity at frequency omega.

    Args:
        omega: photon energy (eV)
        omega_p: plasma frequency (eV)
        gamma: damping rate (eV)
        eps_inf: background permittivity from interband transitions (default: 1.0)

    Returns:
        Complex permittivity ε(ω).
    """
    return eps_inf - omega_p**2 / (omega**2 + 1j * gamma * omega)
