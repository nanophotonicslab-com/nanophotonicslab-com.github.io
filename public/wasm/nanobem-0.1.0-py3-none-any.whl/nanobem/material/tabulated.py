"""Tabulated optical constants for metals.

Data from Johnson & Christy, Phys. Rev. B 6, 4370 (1972).
Uses the same data files as nanobem22 (Hohenester) for exact
reproducibility of reference values.

File format: eV  n  k  (one line per data point)
Internally converted to wavelength (nm) and ε = (n + ik)².
Interpolation via cubic spline on ε(eV), matching nanobem22's approach.
"""

from pathlib import Path

import numpy as np
from scipy.interpolate import CubicSpline


_DATA_DIR = Path(__file__).parent


def _load_dat_file(filename: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load a nanobem22-format .dat file (eV, n, k).

    Returns:
        energies_eV: photon energies in eV
        n: real part of refractive index
        k: imaginary part of refractive index
    """
    path = _DATA_DIR / filename
    data = np.loadtxt(path, comments="%")
    return data[:, 0], data[:, 1], data[:, 2]


def _build_interpolator(filename: str):
    """Build a cubic spline interpolator for ε(eV), matching nanobem22."""
    energies, n, k = _load_dat_file(filename)
    eps = (n + 1j * k) ** 2
    # Separate real and imaginary parts for spline
    spline_re = CubicSpline(energies, eps.real)
    spline_im = CubicSpline(energies, eps.imag)
    return spline_re, spline_im, energies.min(), energies.max()


_gold_re, _gold_im, _gold_emin, _gold_emax = _build_interpolator("gold_jc.dat")
_silver_re, _silver_im, _silver_emin, _silver_emax = _build_interpolator("silver_jc.dat")

_MATERIALS = {
    "Au": (_gold_re, _gold_im, _gold_emin, _gold_emax),
    "Ag": (_silver_re, _silver_im, _silver_emin, _silver_emax),
}


def _ev_to_nm(ev: float) -> float:
    return 1240.0 / ev


def _nm_to_ev(nm: float) -> float:
    return 1240.0 / nm


def load_material(name: str) -> tuple[np.ndarray, np.ndarray]:
    """Load raw tabulated data for a material.

    Args:
        name: material identifier ("Au" or "Ag")

    Returns:
        wavelengths: array of wavelengths (nm), sorted ascending
        permittivity: array of complex permittivity values
    """
    if name not in _MATERIALS:
        raise ValueError(f"Unknown material '{name}'. Available: {list(_MATERIALS.keys())}")

    filenames = {"Au": "gold_jc.dat", "Ag": "silver_jc.dat"}
    energies, n, k = _load_dat_file(filenames[name])
    wavelengths = 1240.0 / energies  # eV → nm
    eps = (n + 1j * k) ** 2

    # Sort by wavelength ascending
    idx = np.argsort(wavelengths)
    return wavelengths[idx], eps[idx]


def interpolate_permittivity(wavelength_nm: float, name: str) -> complex:
    """Get interpolated complex permittivity at a given wavelength.

    Uses cubic spline on ε(eV), matching nanobem22's interpolation.

    Args:
        wavelength_nm: wavelength in nm
        name: material identifier ("Au" or "Ag")

    Returns:
        Complex permittivity ε(λ).
    """
    if name not in _MATERIALS:
        raise ValueError(f"Unknown material '{name}'. Available: {list(_MATERIALS.keys())}")

    spline_re, spline_im, emin, emax = _MATERIALS[name]
    ev = _nm_to_ev(wavelength_nm)

    if ev < emin or ev > emax:
        wl_min = _ev_to_nm(emax)
        wl_max = _ev_to_nm(emin)
        raise ValueError(
            f"Wavelength {wavelength_nm:.1f}nm (={ev:.2f}eV) outside tabulated range "
            f"[{wl_min:.1f}, {wl_max:.1f}]nm for {name}"
        )

    return complex(float(spline_re(ev)), float(spline_im(ev)))


def gold_permittivity(wavelength_nm: float) -> complex:
    """Complex permittivity of gold at given wavelength (nm)."""
    return interpolate_permittivity(wavelength_nm, "Au")


def silver_permittivity(wavelength_nm: float) -> complex:
    """Complex permittivity of silver at given wavelength (nm)."""
    return interpolate_permittivity(wavelength_nm, "Ag")
