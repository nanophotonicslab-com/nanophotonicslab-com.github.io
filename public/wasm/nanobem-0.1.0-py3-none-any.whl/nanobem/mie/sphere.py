"""Mie theory for homogeneous spheres.

Computes Mie coefficients (a_n, b_n) and derived quantities
(extinction, scattering, absorption efficiencies) for a sphere
of complex refractive index m and size parameter x = 2πr/λ.

Reference: Bohren & Huffman, "Absorption and Scattering of Light
by Small Particles", Chapters 4.

The implementation uses the logarithmic derivative method (Dn)
for numerical stability, following Wiscombe (1980).
"""

import numpy as np
from scipy.special import spherical_jn, spherical_yn


def _riccati_bessel_psi(n: int, z: complex) -> tuple[complex, complex]:
    """Riccati-Bessel function ψ_n(z) = z·j_n(z) and its derivative.

    ψ_n(z) = z · j_n(z)
    ψ_n'(z) = j_n(z) + z · j_n'(z)
    """
    jn = spherical_jn(n, z)
    jn_d = spherical_jn(n, z, derivative=True)
    psi = z * jn
    psi_d = jn + z * jn_d
    return psi, psi_d


def _riccati_bessel_xi(n: int, x: float) -> tuple[complex, complex]:
    """Riccati-Bessel function ξ_n(x) = x·h_n^(1)(x) and its derivative.

    ξ_n(x) = x · (j_n(x) + i·y_n(x))
    For real argument x only.
    """
    jn = spherical_jn(n, x)
    yn = spherical_yn(n, x)
    jn_d = spherical_jn(n, x, derivative=True)
    yn_d = spherical_yn(n, x, derivative=True)

    xi = x * (jn + 1j * yn)
    xi_d = (jn + 1j * yn) + x * (jn_d + 1j * yn_d)
    return xi, xi_d


def mie_coefficients(
    x: float, m: complex, n_max: int | None = None
) -> tuple[np.ndarray, np.ndarray]:
    """Compute Mie coefficients a_n and b_n.

    Args:
        x: size parameter 2πr/λ (in surrounding medium)
        m: complex refractive index of sphere relative to medium
        n_max: maximum multipole order (default: Wiscombe criterion)

    Returns:
        a: array of a_n coefficients (n = 1, ..., n_max)
        b: array of b_n coefficients (n = 1, ..., n_max)
    """
    if n_max is None:
        # Wiscombe (1980) criterion
        n_max = int(x + 4 * x**(1/3) + 2)
        n_max = max(n_max, 3)

    mx = m * x
    a = np.zeros(n_max, dtype=complex)
    b = np.zeros(n_max, dtype=complex)

    for n in range(1, n_max + 1):
        psi_mx, psi_mx_d = _riccati_bessel_psi(n, mx)
        psi_x, psi_x_d = _riccati_bessel_psi(n, x)
        xi_x, xi_x_d = _riccati_bessel_xi(n, x)

        # Bohren & Huffman, Eq. 4.53
        a[n - 1] = (m * psi_mx * psi_x_d - psi_x * psi_mx_d) / \
                    (m * psi_mx * xi_x_d - xi_x * psi_mx_d)

        b[n - 1] = (psi_mx * psi_x_d - m * psi_x * psi_mx_d) / \
                    (psi_mx * xi_x_d - m * xi_x * psi_mx_d)

    return a, b


def extinction_efficiency(
    x: float, m: complex, n_max: int | None = None
) -> float:
    """Compute extinction efficiency Q_ext.

    Q_ext = (2/x²) Σ (2n+1) Re(a_n + b_n)

    Reference: Bohren & Huffman, Eq. 4.61.
    """
    a, b = mie_coefficients(x, m, n_max)
    ns = np.arange(1, len(a) + 1)
    q_ext = (2.0 / x**2) * np.sum((2 * ns + 1) * np.real(a + b))
    return float(q_ext)


def scattering_efficiency(
    x: float, m: complex, n_max: int | None = None
) -> float:
    """Compute scattering efficiency Q_sca.

    Q_sca = (2/x²) Σ (2n+1) (|a_n|² + |b_n|²)

    Reference: Bohren & Huffman, Eq. 4.61.
    """
    a, b = mie_coefficients(x, m, n_max)
    ns = np.arange(1, len(a) + 1)
    q_sca = (2.0 / x**2) * np.sum((2 * ns + 1) * (np.abs(a)**2 + np.abs(b)**2))
    return float(q_sca)
