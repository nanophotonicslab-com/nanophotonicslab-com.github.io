"""Built-in nanoparticle shape generators.

Provides BoundaryMesh instances for common geometries.
Uses trimesh primitives under the hood.
"""

import trimesh

from .boundary import BoundaryMesh


def sphere_mesh(radius: float = 1.0, subdivisions: int = 3) -> BoundaryMesh:
    """Create an icosphere mesh.

    Args:
        radius: sphere radius (in nm or any consistent unit)
        subdivisions: icosphere subdivision level (2→162v, 3→642v, 4→2562v)
    """
    mesh = trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius)
    return BoundaryMesh(mesh)


def rod_mesh(
    radius: float = 1.0,
    aspect_ratio: float = 3.0,
    subdivisions: int = 3,
) -> BoundaryMesh:
    """Create a capsule (rod) mesh.

    A capsule is a cylinder with hemispherical caps. Total length = aspect_ratio * 2 * radius.

    Args:
        radius: rod radius
        aspect_ratio: total length / diameter (must be >= 1.0)
        subdivisions: mesh density
    """
    if aspect_ratio < 1.0:
        raise ValueError("aspect_ratio must be >= 1.0")

    total_length = aspect_ratio * 2 * radius
    mesh = trimesh.creation.capsule(height=total_length - 2 * radius, radius=radius)

    # Refine by subdivision if requested beyond default
    for _ in range(max(0, subdivisions - 2)):
        mesh = mesh.subdivide()

    return BoundaryMesh(mesh)
