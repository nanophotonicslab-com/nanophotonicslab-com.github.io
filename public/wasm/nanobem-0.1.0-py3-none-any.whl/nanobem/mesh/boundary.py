"""Boundary element mesh — thin wrapper around trimesh.

Adds BEM-specific functionality: face centroids, quadrature points
on triangular elements, and validation for BEM suitability.
"""

import numpy as np
import trimesh


# Gaussian quadrature rules on the reference triangle (0,0)-(1,0)-(0,1).
# Points are (u, v) barycentric-ish coordinates, weights sum to 0.5 (triangle area).
_QUADRATURE_RULES = {
    1: {
        "points": np.array([[1/3, 1/3]]),
        "weights": np.array([0.5]),
    },
    3: {
        "points": np.array([
            [1/6, 1/6],
            [2/3, 1/6],
            [1/6, 2/3],
        ]),
        "weights": np.array([1/6, 1/6, 1/6]),
    },
    4: {
        "points": np.array([
            [1/3, 1/3],
            [1/5, 1/5],
            [3/5, 1/5],
            [1/5, 3/5],
        ]),
        "weights": np.array([-27/96, 25/96, 25/96, 25/96]),
    },
}


class BoundaryMesh:
    """Boundary element mesh for BEM computation.

    Wraps a trimesh.Trimesh and adds BEM-specific properties and methods.
    """

    def __init__(self, mesh: trimesh.Trimesh):
        """Create from a trimesh object.

        Args:
            mesh: a trimesh.Trimesh (must be triangular).
        """
        if not isinstance(mesh, trimesh.Trimesh):
            raise TypeError(f"Expected trimesh.Trimesh, got {type(mesh)}")

        # Ensure consistent outward normals
        mesh.fix_normals()
        self._mesh = mesh

    @property
    def vertices(self) -> np.ndarray:
        """Vertex positions (N_v, 3)."""
        return self._mesh.vertices

    @property
    def faces(self) -> np.ndarray:
        """Face vertex indices (N_f, 3)."""
        return self._mesh.faces

    @property
    def n_vertices(self) -> int:
        return len(self._mesh.vertices)

    @property
    def n_faces(self) -> int:
        return len(self._mesh.faces)

    @property
    def face_normals(self) -> np.ndarray:
        """Outward-pointing unit face normals (N_f, 3)."""
        return self._mesh.face_normals

    @property
    def vertex_normals(self) -> np.ndarray:
        """Unit vertex normals (N_v, 3), area-weighted average of adjacent faces."""
        return self._mesh.vertex_normals

    @property
    def face_centroids(self) -> np.ndarray:
        """Face centroid positions (N_f, 3)."""
        return self._mesh.triangles_center

    @property
    def face_areas(self) -> np.ndarray:
        """Face areas (N_f,)."""
        return self._mesh.area_faces

    @property
    def total_area(self) -> float:
        """Total surface area."""
        return float(self._mesh.area)

    @property
    def is_watertight(self) -> bool:
        """Whether the mesh is closed (no boundary edges)."""
        return self._mesh.is_watertight

    def quadrature(self, order: int = 3) -> tuple[np.ndarray, np.ndarray]:
        """Compute Gaussian quadrature points and weights on each face.

        Args:
            order: quadrature order (1, 3, or 4 points per face)

        Returns:
            points: (N_f, n_points, 3) — quadrature points in 3D
            weights: (N_f, n_points) — quadrature weights (sum to face area)
        """
        if order not in _QUADRATURE_RULES:
            raise ValueError(f"Quadrature order {order} not available. Use {list(_QUADRATURE_RULES)}")

        rule = _QUADRATURE_RULES[order]
        ref_pts = rule["points"]  # (n_pts, 2) — (u, v) on reference triangle
        ref_wts = rule["weights"]  # (n_pts,) — sum to 0.5

        triangles = self._mesh.triangles  # (N_f, 3, 3)
        v0 = triangles[:, 0, :]  # (N_f, 3)
        v1 = triangles[:, 1, :]
        v2 = triangles[:, 2, :]

        n_pts = len(ref_pts)
        points = np.zeros((self.n_faces, n_pts, 3))
        weights = np.zeros((self.n_faces, n_pts))

        for i, (u, v) in enumerate(ref_pts):
            # Map from reference triangle to physical: P = v0 + u*(v1-v0) + v*(v2-v0)
            points[:, i, :] = v0 + u * (v1 - v0) + v * (v2 - v0)
            # Weight = ref_weight * 2 * face_area (reference triangle has area 0.5)
            weights[:, i] = ref_wts[i] * 2 * self.face_areas

        return points, weights
