"""nanobem — Hardware-accelerated Galerkin BEM for nanophotonics.

Quick start:
    import nanobem as nb

    mesh = nb.sphere_mesh(radius=25, subdivisions=2)
    result = nb.solve(mesh, nb.gold(530), eps_medium=1.33**2, wavelength=530)
    print(f"C_ext = {result.extinction:.0f} nm²")
"""

# High-level API
from nanobem.api import solve, BEMResult

# Mesh creation
from nanobem.mesh.shapes import sphere_mesh, rod_mesh

# Materials (wavelength in nm → complex permittivity)
from nanobem.material.tabulated import gold_permittivity as gold
from nanobem.material.tabulated import silver_permittivity as silver

# Mie theory (analytical reference)
from nanobem.mie.sphere import extinction_efficiency, scattering_efficiency

__all__ = [
    "solve",
    "BEMResult",
    "sphere_mesh",
    "rod_mesh",
    "gold",
    "silver",
    "extinction_efficiency",
    "scattering_efficiency",
]
