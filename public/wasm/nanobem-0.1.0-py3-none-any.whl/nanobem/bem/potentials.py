"""Galerkin single-layer and double-layer potential matrices.

Assembles the matrices [[S]] and [[D]] for the PMCHWT BEM formulation
using Raviart-Thomas (RT0) basis functions and numerical quadrature
over triangle pairs.

Single-layer (Eq. A.11a):
    [[S]]_{ia,i'a'} = ∫∫ [f_{ia}·f_{i'a'} - div(f_{ia})·div(f_{i'a'})/k²] g dS dS'

Double-layer (Eq. A.11b):
    [[D]]_{ia,i'a'} = ∫∫ f_{ia} · [∇'g × f_{i'a'}] dS dS'

Reference: Hohenester et al., CPC 276, 108337 (2022), Appendix A.
"""

import numpy as np

from nanobem.mesh.boundary import BoundaryMesh
from nanobem.mesh.edges import extract_edges
from nanobem.mesh.raviart_thomas import evaluate_rt
from nanobem.bem.green_retarded import green_scalar, green_gradient

try:
    from nanobem.bem.potentials_jax import single_layer_jax, double_layer_jax
    _HAS_JAX = True
except ImportError:
    _HAS_JAX = False


def single_layer_matrix(
    mesh: BoundaryMesh,
    edges_info: dict,
    k: complex,
    quad_order: int = 4,
    use_duffy: bool = False,
    n_duffy: int = 4,
    refine_touching: bool = False,
) -> np.ndarray:
    """Assemble the single-layer potential matrix [[S]].

    [[S]]_{νν'} = Σ_{i,a → ν} Σ_{i',a' → ν'} ∫_{τ_i} ∫_{τ_{i'}}
        [f_{ia}(s)·f_{i'a'}(s') - div(f_{ia})·div(f_{i'a'}) / k²] g(s,s') dS dS'

    Uses JAX vectorization when available, falls back to NumPy loops.

    Args:
        mesh: boundary mesh
        edges_info: dict from extract_edges()
        k: wavenumber (complex)
        quad_order: quadrature order per triangle (3 or 4)
        use_duffy: if True, use Duffy transform for self-interaction
        n_duffy: Duffy quadrature order (points per dimension)
        refine_touching: if True, use refined quadrature for adjacent pairs

    Returns:
        S: (n_edges, n_edges) complex matrix
    """
    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    f_vals, div_f = evaluate_rt(mesh, edges_info, quad_pts)

    if _HAS_JAX:
        S = single_layer_jax(
            quad_pts, quad_wts, f_vals, div_f,
            edges_info["face_edges"], edges_info["n_edges"],
            k, use_duffy=use_duffy,
        )
    else:
        S = _single_layer_numpy(
            mesh, edges_info, k, quad_pts, quad_wts, f_vals, div_f,
            use_duffy=use_duffy,
        )

    if use_duffy:
        _add_duffy_self_correction(S, mesh, edges_info, k, quad_order, n_duffy)

    if refine_touching:
        _add_touching_refinement(S, mesh, edges_info, k, quad_order)

    return S


def _single_layer_numpy(
    mesh, edges_info, k, quad_pts, quad_wts, f_vals, div_f,
    use_duffy=False,
):
    """NumPy loop implementation of [[S]] (fallback when JAX unavailable)."""
    n_edges = edges_info["n_edges"]
    n_faces = mesh.n_faces
    face_edges = edges_info["face_edges"]
    n_quad = quad_pts.shape[1]

    S = np.zeros((n_edges, n_edges), dtype=complex)

    for ip in range(n_faces):
        s_prime = quad_pts[ip]
        w_prime = quad_wts[ip]

        for iq_p in range(n_quad):
            sp = s_prime[iq_p]
            wp = w_prime[iq_p]

            diff = quad_pts - sp[np.newaxis, np.newaxis, :]
            R = np.linalg.norm(diff, axis=2)
            R_safe = np.where(R == 0, 1.0, R)
            g_vals = np.exp(1j * k * R) / (4 * np.pi * R_safe)
            g_smooth_limit = 1j * k / (4 * np.pi) if use_duffy else 0.0
            g_vals = np.where(R == 0, g_smooth_limit, g_vals)

            for ap in range(3):
                nu_p = face_edges[ip, ap]
                f_ap = f_vals[ip, ap, iq_p, :]
                div_ap = div_f[ip, ap]

                gw = g_vals * quad_wts * wp

                for a in range(3):
                    dot_ff = np.sum(
                        f_vals[:, a, :, :] * f_ap[np.newaxis, np.newaxis, :],
                        axis=2
                    )

                    if abs(k) > 1e-30:
                        div_term = div_f[:, a] * div_ap / (k ** 2)
                    else:
                        div_term = np.zeros(n_faces)

                    integrand = dot_ff - div_term[:, np.newaxis]
                    contribution = np.sum(integrand * gw, axis=1)

                    np.add.at(S, (face_edges[:, a], nu_p), contribution)

    return S


def _add_duffy_self_correction(
    S: np.ndarray,
    mesh: BoundaryMesh,
    edges_info: dict,
    k: complex,
    quad_order: int,
    n_duffy: int,
) -> None:
    """Add Duffy correction for self-interaction on identical triangles.

    Vectorized over all faces: computes the singular 1/(4πR) contribution
    via Duffy polar coordinates and subtracts the standard quadrature
    approximation of the same static kernel.

    Strategy: singularity subtraction.
    For identical triangles, split g = 1/(4πR) + [g - 1/(4πR)].
    - The smooth part [g - 1/(4πR)] is already in S (finite at R=0: ik/(4π)).
    - The singular 1/(4πR) needs Duffy polar coordinates.
    """
    N_f = mesh.n_faces
    face_edges = edges_info["face_edges"]

    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    N_q = quad_pts.shape[1]
    f_vals, div_f = evaluate_rt(mesh, edges_info, quad_pts)

    from nanobem.bem.singular import _gauss_legendre_01

    rho_pts, rho_wts = _gauss_legendre_01(n_duffy)
    N_rho = len(rho_pts)
    N_theta = 2 * n_duffy
    theta_pts, theta_wts = _gauss_legendre_01(N_theta)
    theta_pts = theta_pts * 2 * np.pi
    theta_wts = theta_wts * 2 * np.pi

    # --- Per-face 2D coordinate system ---
    triangles = mesh._mesh.triangles  # (N_f, 3, 3)
    v0 = triangles[:, 0, :]  # (N_f, 3)
    e1 = triangles[:, 1, :] - v0
    e2 = triangles[:, 2, :] - v0

    e1_len = np.linalg.norm(e1, axis=1, keepdims=True)  # (N_f, 1)
    e1_n = e1 / e1_len  # (N_f, 3)
    e2_proj = np.sum(e2 * e1_n, axis=1, keepdims=True)  # (N_f, 1)
    e2_perp = e2 - e2_proj * e1_n
    e2_perp_len = np.linalg.norm(e2_perp, axis=1, keepdims=True)
    e2_n = e2_perp / e2_perp_len  # (N_f, 3)

    areas = mesh.face_areas  # (N_f,)

    # Triangle vertices in local 2D: v0=(0,0), v1=(|e1|,0), v2=(e2·ê1, |e2⊥|)
    v1x = e1_len[:, 0]  # (N_f,)
    v2x = e2_proj[:, 0]
    v2y = e2_perp_len[:, 0]

    # Project quad points to 2D
    ds = quad_pts - v0[:, None, :]  # (N_f, N_q, 3)
    s2d_x = np.sum(ds * e1_n[:, None, :], axis=2)  # (N_f, N_q)
    s2d_y = np.sum(ds * e2_n[:, None, :], axis=2)

    # Direction vectors
    cos_t = np.cos(theta_pts)  # (N_theta,)
    sin_t = np.sin(theta_pts)

    # 3D direction per face per theta: (N_f, N_theta, 3)
    d3d = (cos_t[None, :, None] * e1_n[:, None, :] +
           sin_t[None, :, None] * e2_n[:, None, :])

    # --- Vectorized ray-triangle intersection for all (face, quad, theta) ---
    # 3 edges: (0,0)→(v1x,0), (v1x,0)→(v2x,v2y), (v2x,v2y)→(0,0)
    rho_max = np.full((N_f, N_q, N_theta), np.inf)

    edge_p0 = [(np.zeros(N_f), np.zeros(N_f)), (v1x, np.zeros(N_f)), (v2x, v2y)]
    edge_p1 = [(v1x, np.zeros(N_f)), (v2x, v2y), (np.zeros(N_f), np.zeros(N_f))]

    for (p0x, p0y), (p1x, p1y) in zip(edge_p0, edge_p1):
        dx = p1x - p0x  # (N_f,)
        dy = p1y - p0y

        dpx = p0x[:, None] - s2d_x  # (N_f, N_q)
        dpy = p0y[:, None] - s2d_y

        # denom[i, theta] = cos_t * dy[i] - sin_t * dx[i]
        denom = (cos_t[None, :] * dy[:, None] -
                 sin_t[None, :] * dx[:, None])  # (N_f, N_theta)

        # Broadcast to (N_f, N_q, N_theta)
        safe_den = np.where(np.abs(denom[:, None, :]) < 1e-15, 1.0,
                            denom[:, None, :])

        num_t = (dpx[:, :, None] * dy[:, None, None] -
                 dpy[:, :, None] * dx[:, None, None])
        num_s = (dpx[:, :, None] * sin_t[None, None, :] -
                 dpy[:, :, None] * cos_t[None, None, :])

        t_val = num_t / safe_den
        s_val = num_s / safe_den

        valid = ((np.abs(denom[:, None, :]) > 1e-15) &
                 (t_val > 1e-12) & (s_val >= 0) & (s_val <= 1))
        rho_max = np.where(valid & (t_val < rho_max), t_val, rho_max)

    rho_max = np.where(rho_max == np.inf, 0.0, rho_max)
    # rho_max: (N_f, N_q, N_theta)

    # --- Duffy points: s_prime = s + rho*rmax * d3d ---
    # rho_actual: (N_f, N_q, N_theta, N_rho)
    rho_actual = rho_pts[None, None, None, :] * rho_max[:, :, :, None]
    rho_w = rho_wts[None, None, None, :] * rho_max[:, :, :, None]

    # s_prime: (N_f, N_q, N_theta, N_rho, 3)
    s_prime = (quad_pts[:, :, None, None, :] +
               rho_actual[..., None] * d3d[:, None, :, None, :])

    # Combined weights: (N_f, N_q, N_theta, N_rho)
    w_duffy = quad_wts[:, :, None, None] * theta_wts[None, None, :, None] * rho_w

    # --- Standard quadrature: static kernel on same-face pairs ---
    # R_std[i, q, q']: (N_f, N_q, N_q)
    diff_std = quad_pts[:, :, None, :] - quad_pts[:, None, :, :]
    R_std = np.linalg.norm(diff_std, axis=3)
    R_std_safe = np.maximum(R_std, 1e-30)
    g_std = np.where(R_std > 1e-15, 1.0 / (4 * np.pi * R_std_safe), 0.0)
    w_std = quad_wts[:, :, None] * quad_wts[:, None, :]  # (N_f, N_q, N_q)

    # --- Loop over 9 edge pairs (small, no need to vectorize) ---
    for a in range(3):
        nu_a = face_edges[:, a]  # (N_f,)
        div_a = div_f[:, a]
        f_a = f_vals[:, a, :, :]  # (N_f, N_q, 3)

        for ap in range(3):
            nu_ap = face_edges[:, ap]
            div_ap = div_f[:, ap]

            if abs(k) > 1e-30:
                div_term = div_a * div_ap / (k ** 2)  # (N_f,)
            else:
                div_term = np.zeros(N_f)

            # Evaluate f_ap at Duffy s_prime points
            opp = mesh.vertices[edges_info["opposite_vertices"][:, ap]]  # (N_f, 3)
            l_ap = edges_info["edge_lengths"][face_edges[:, ap]]  # (N_f,)
            sign_ap = edges_info["edge_signs"][:, ap]
            pf = sign_ap * l_ap / (2 * areas)  # (N_f,)

            # f_ap at s_prime: (N_f, N_q, N_theta, N_rho, 3)
            f_ap_val = pf[:, None, None, None, None] * (
                s_prime - opp[:, None, None, None, :])

            # f_a · f_ap: (N_f, N_q, N_theta, N_rho)
            ff_duffy = np.sum(f_a[:, :, None, None, :] * f_ap_val, axis=4)

            # Duffy integral of [f·f' - div/k²] / (4π)
            integrand = (ff_duffy - div_term[:, None, None, None]) / (4 * np.pi)
            I_duffy = np.sum(integrand * w_duffy, axis=(1, 2, 3))  # (N_f,)

            # Standard quadrature of static kernel
            f_a_std = f_vals[:, a, :, :]   # (N_f, N_q, 3)
            f_ap_std = f_vals[:, ap, :, :]  # (N_f, N_q, 3)
            ff_std = np.sum(
                f_a_std[:, :, None, :] * f_ap_std[:, None, :, :], axis=3
            )  # (N_f, N_q, N_q)
            I_standard = np.sum(
                w_std * (ff_std - div_term[:, None, None]) * g_std, axis=(1, 2)
            )  # (N_f,)

            # Add correction
            np.add.at(S, (nu_a, nu_ap), I_duffy - I_standard)


def _subdivide_triangle(v0, v1, v2):
    """Subdivide a triangle into 4 sub-triangles by midpoint splitting."""
    m01 = (v0 + v1) / 2
    m12 = (v1 + v2) / 2
    m02 = (v0 + v2) / 2
    return [(v0, m01, m02), (m01, v1, m12), (m02, m12, v2), (m01, m12, m02)]


def _subdivide_recursive(v0, v1, v2, levels):
    """Recursively subdivide a triangle. Returns list of (sv0,sv1,sv2) tuples."""
    if levels <= 0:
        return [(v0, v1, v2)]
    subs = _subdivide_triangle(v0, v1, v2)
    result = []
    for sv0, sv1, sv2 in subs:
        result.extend(_subdivide_recursive(sv0, sv1, sv2, levels - 1))
    return result


def _add_touching_refinement(
    S: np.ndarray,
    mesh: BoundaryMesh,
    edges_info: dict,
    k: complex,
    quad_order: int,
    refine_levels: int = 2,
) -> None:
    """Add refined quadrature correction for touching triangle pairs.

    For triangle pairs sharing an edge or vertex, recursively subdivides
    each triangle and recomputes with 3-point quadrature per sub-triangle.
    levels=2 gives 16 sub-tris × 3 pts = 48 points per triangle, 2304 pairs.

    The correction = (refined integral) - (standard integral) is added to S.
    """
    from nanobem.mesh.raviart_thomas import evaluate_rt
    from nanobem.bem.singular import classify_triangle_pairs

    n_faces = mesh.n_faces
    face_edges = edges_info["face_edges"]

    # Standard quadrature (what the main loop used)
    quad_pts_std, quad_wts_std = mesh.quadrature(order=quad_order)
    n_std = quad_pts_std.shape[1]
    f_std, div_std = evaluate_rt(mesh, edges_info, quad_pts_std)

    # Build refined quadrature per face
    triangles = mesh._mesh.triangles
    ref_3pt = np.array([[1/6, 1/6], [2/3, 1/6], [1/6, 2/3]])
    ref_3wt = np.array([1/6, 1/6, 1/6])
    n_sub = 4 ** refine_levels
    n_ref = n_sub * 3

    quad_pts_ref = np.zeros((n_faces, n_ref, 3))
    quad_wts_ref = np.zeros((n_faces, n_ref))

    for i_face in range(n_faces):
        v0, v1, v2 = triangles[i_face]
        sub_tris = _subdivide_recursive(v0, v1, v2, refine_levels)
        sub_area = mesh.face_areas[i_face] / n_sub
        for s_idx, (sv0, sv1, sv2) in enumerate(sub_tris):
            for q_idx, (u, v) in enumerate(ref_3pt):
                pt = sv0 + u * (sv1 - sv0) + v * (sv2 - sv0)
                idx = s_idx * 3 + q_idx
                quad_pts_ref[i_face, idx] = pt
                quad_wts_ref[i_face, idx] = ref_3wt[q_idx] * 2 * sub_area

    # RT basis at refined points
    f_ref = np.zeros((n_faces, 3, n_ref, 3))
    div_ref = np.zeros((n_faces, 3))
    for i_face in range(n_faces):
        area = mesh.face_areas[i_face]
        for a in range(3):
            ge = face_edges[i_face, a]
            l_a = edges_info["edge_lengths"][ge]
            sign = edges_info["edge_signs"][i_face, a]
            opp = mesh.vertices[edges_info["opposite_vertices"][i_face, a]]
            pf = sign * l_a / (2 * area)
            for iq in range(n_ref):
                f_ref[i_face, a, iq] = pf * (quad_pts_ref[i_face, iq] - opp)
            div_ref[i_face, a] = sign * l_a / area

    # Get touching pairs
    pairs = classify_triangle_pairs(mesh)
    touching = pairs["touching"]

    for i_face, j_face in touching:
        for a in range(3):
            nu = face_edges[i_face, a]
            for ap in range(3):
                nu_p = face_edges[j_face, ap]

                div_term_r = div_ref[i_face, a] * div_ref[j_face, ap] / (k**2) \
                    if abs(k) > 1e-30 else 0.0

                # Refined integral
                I_ref = 0.0 + 0j
                for iq in range(n_ref):
                    s = quad_pts_ref[i_face, iq]
                    w = quad_wts_ref[i_face, iq]
                    fa = f_ref[i_face, a, iq]
                    for iq_p in range(n_ref):
                        sp = quad_pts_ref[j_face, iq_p]
                        wp = quad_wts_ref[j_face, iq_p]
                        fap = f_ref[j_face, ap, iq_p]
                        R = np.linalg.norm(s - sp)
                        if R < 1e-15:
                            continue
                        g = np.exp(1j * k * R) / (4 * np.pi * R)
                        I_ref += w * wp * (np.dot(fa, fap) - div_term_r) * g

                # Standard integral
                I_std = 0.0 + 0j
                div_term_s = div_std[i_face, a] * div_std[j_face, ap] / (k**2) \
                    if abs(k) > 1e-30 else 0.0
                for iq in range(n_std):
                    s = quad_pts_std[i_face, iq]
                    w = quad_wts_std[i_face, iq]
                    fa = f_std[i_face, a, iq]
                    for iq_p in range(n_std):
                        sp = quad_pts_std[j_face, iq_p]
                        wp = quad_wts_std[j_face, iq_p]
                        fap = f_std[j_face, ap, iq_p]
                        R = np.linalg.norm(s - sp)
                        if R < 1e-15:
                            continue
                        g = np.exp(1j * k * R) / (4 * np.pi * R)
                        I_std += w * wp * (np.dot(fa, fap) - div_term_s) * g

                correction = I_ref - I_std
                S[nu, nu_p] += correction
                S[nu_p, nu] += correction


def double_layer_matrix(
    mesh: BoundaryMesh,
    edges_info: dict,
    k: complex,
    quad_order: int = 4,
) -> np.ndarray:
    """Assemble the double-layer potential matrix [[D]].

    [[D]]_{νν'} = Σ_{i,a → ν} Σ_{i',a' → ν'} ∫_{τ_i} ∫_{τ_{i'}}
        f_{ia}(s) · [∇'g(s,s') × f_{i'a'}(s')] dS dS'

    Uses JAX vectorization when available, falls back to NumPy loops.

    Args:
        mesh: boundary mesh
        edges_info: dict from extract_edges()
        k: wavenumber
        quad_order: quadrature order

    Returns:
        D: (n_edges, n_edges) complex matrix
    """
    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    f_vals, _ = evaluate_rt(mesh, edges_info, quad_pts)

    if _HAS_JAX:
        return double_layer_jax(
            quad_pts, quad_wts, f_vals,
            edges_info["face_edges"], edges_info["n_edges"], k,
        )

    return _double_layer_numpy(mesh, edges_info, k, quad_pts, quad_wts, f_vals)


def _double_layer_numpy(mesh, edges_info, k, quad_pts, quad_wts, f_vals):
    """NumPy loop implementation of [[D]] (fallback when JAX unavailable)."""
    n_edges = edges_info["n_edges"]
    n_faces = mesh.n_faces
    face_edges = edges_info["face_edges"]
    n_quad = quad_pts.shape[1]

    D = np.zeros((n_edges, n_edges), dtype=complex)

    for ip in range(n_faces):
        s_prime = quad_pts[ip]
        w_prime = quad_wts[ip]

        for iq_p in range(n_quad):
            sp = s_prime[iq_p]
            wp = w_prime[iq_p]

            diff = quad_pts - sp[np.newaxis, np.newaxis, :]
            R = np.linalg.norm(diff, axis=2, keepdims=True)
            R_safe = np.where(R == 0, 1.0, R)
            g_vals = np.exp(1j * k * R) / (4 * np.pi * R_safe)
            g_vals = np.where(R == 0, 0.0, g_vals)

            grad_prime_g = -(1j * k - 1.0 / R_safe) * diff / R_safe * g_vals

            for ap in range(3):
                nu_p = face_edges[ip, ap]
                f_ap = f_vals[ip, ap, iq_p, :]

                curl_term = np.cross(grad_prime_g, f_ap[np.newaxis, np.newaxis, :])

                for a in range(3):
                    dot_val = np.sum(
                        f_vals[:, a, :, :] * curl_term, axis=2
                    )

                    contribution = np.sum(dot_val * quad_wts * wp, axis=1)

                    np.add.at(D, (face_edges[:, a], nu_p), contribution)

    return D
