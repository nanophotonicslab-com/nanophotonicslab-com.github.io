"""JAX-accelerated single-layer and double-layer potential matrices.

Replaces the O(N²) Python loops in potentials.py with fully vectorized
JAX operations: pairwise Green's function + einsum contractions.

Memory: O(N_f² × N_q²) for the Green's function matrix.
For 284 faces, N_q=4: ~21 MB. For 1280 faces: ~420 MB.
"""

import functools

import jax
import jax.numpy as jnp
import numpy as np

jax.config.update("jax_enable_x64", True)


def single_layer_jax(
    quad_pts: np.ndarray,
    quad_wts: np.ndarray,
    f_vals: np.ndarray,
    div_f: np.ndarray,
    face_edges: np.ndarray,
    n_edges: int,
    k: complex,
    use_duffy: bool = False,
) -> np.ndarray:
    """Compute [[S]] using JAX vectorization.

    Same numerical result as the NumPy loop, but fully vectorized.
    Duffy self-correction is NOT included — apply separately.

    Args:
        quad_pts: (N_f, N_q, 3) quadrature points
        quad_wts: (N_f, N_q) quadrature weights
        f_vals: (N_f, 3, N_q, 3) RT basis values
        div_f: (N_f, 3) RT divergences
        face_edges: (N_f, 3) global edge indices
        n_edges: number of edges
        k: complex wavenumber
        use_duffy: if True, use smooth limit ik/(4π) at R=0

    Returns:
        S: (n_edges, n_edges) complex numpy array
    """
    return np.array(_sl_kernel(
        jnp.asarray(quad_pts),
        jnp.asarray(quad_wts),
        jnp.asarray(f_vals),
        jnp.asarray(div_f),
        jnp.asarray(face_edges),
        n_edges,
        jnp.asarray(complex(k)),
        use_duffy,
    ))


@functools.partial(jax.jit, static_argnums=(5, 7))
def _sl_kernel(quad_pts, quad_wts, f_vals, div_f, face_edges, n_edges, k, use_duffy):
    N_f, N_q, _ = quad_pts.shape

    # 1. Pairwise Green's function: G[i*N_q+q, j*N_q+p] → reshaped to (N_f,N_q,N_f,N_q)
    pts = quad_pts.reshape(-1, 3)  # (M, 3)
    diff = pts[:, None, :] - pts[None, :, :]  # (M, M, 3)
    R = jnp.sqrt(jnp.sum(diff ** 2, axis=2))  # (M, M)
    R_safe = jnp.maximum(R, 1e-30)

    g = jnp.exp(1j * k * R) / (4 * jnp.pi * R_safe)  # (M, M)

    if use_duffy:
        g = jnp.where(R < 1e-30, 1j * k / (4 * jnp.pi), g)
    else:
        g = jnp.where(R < 1e-30, 0.0 + 0j, g)

    G = g.reshape(N_f, N_q, N_f, N_q)

    # 2. Weight by quadrature: Gw[i,q,j,p] = G * w[i,q] * w[j,p]
    Gw = G * quad_wts[:, :, None, None] * quad_wts[None, None, :, :]

    # 3. f·f' term via two-step einsum
    # fG[i,a,x,j,p] = Σ_q f[i,a,q,x] · Gw[i,q,j,p]
    fG = jnp.einsum('iaqx,iqjp->iaxjp', f_vals, Gw)
    # S_ff[i,a,j,b] = Σ_{p,x} fG[i,a,x,j,p] · f[j,b,p,x]
    S_ff = jnp.einsum('iaxjp,jbpx->iajb', fG, f_vals)

    # 4. div·div'/k² term
    Gw_sum = jnp.sum(Gw, axis=(1, 3))  # (N_f, N_f)
    S_div = jnp.einsum('ia,jb,ij->iajb', div_f, div_f, Gw_sum) / (k ** 2)

    # 5. Local contributions
    S_local = S_ff - S_div  # (N_f, 3, N_f, 3)

    # 6. Scatter to global DOF indices
    row = jnp.broadcast_to(face_edges[:, :, None, None], S_local.shape)
    col = jnp.broadcast_to(face_edges[None, None, :, :], S_local.shape)

    S = jnp.zeros((n_edges, n_edges), dtype=jnp.complex128)
    S = S.at[row.ravel(), col.ravel()].add(S_local.ravel())

    return S


def double_layer_jax(
    quad_pts: np.ndarray,
    quad_wts: np.ndarray,
    f_vals: np.ndarray,
    face_edges: np.ndarray,
    n_edges: int,
    k: complex,
) -> np.ndarray:
    """Compute [[D]] using JAX vectorization.

    Args:
        quad_pts: (N_f, N_q, 3) quadrature points
        quad_wts: (N_f, N_q) quadrature weights
        f_vals: (N_f, 3, N_q, 3) RT basis values
        face_edges: (N_f, 3) global edge indices
        n_edges: number of edges
        k: complex wavenumber

    Returns:
        D: (n_edges, n_edges) complex numpy array
    """
    return np.array(_dl_kernel(
        jnp.asarray(quad_pts),
        jnp.asarray(quad_wts),
        jnp.asarray(f_vals),
        jnp.asarray(face_edges),
        n_edges,
        jnp.asarray(complex(k)),
    ))


@functools.partial(jax.jit, static_argnums=(4,))
def _dl_kernel(quad_pts, quad_wts, f_vals, face_edges, n_edges, k):
    N_f, N_q, _ = quad_pts.shape

    # 1. Pairwise Green's gradient: ∇'g(s,s') = -(ik-1/R)(s-s')/R · g
    pts = quad_pts.reshape(-1, 3)  # (M, 3)
    diff = pts[:, None, :] - pts[None, :, :]  # (M, M, 3) — s - s'
    R = jnp.sqrt(jnp.sum(diff ** 2, axis=2))  # (M, M)
    R_safe = jnp.maximum(R, 1e-30)

    g = jnp.exp(1j * k * R) / (4 * jnp.pi * R_safe)  # (M, M)
    g = jnp.where(R < 1e-30, 0.0 + 0j, g)

    # ∇'g = -(ik - 1/R)(s-s')/R · g → (M, M, 3)
    coeff = -(1j * k - 1.0 / R_safe)  # (M, M)
    grad_prime = coeff[:, :, None] * diff / R_safe[:, :, None] * g[:, :, None]
    grad_prime = jnp.where(R[:, :, None] < 1e-30, 0.0, grad_prime)  # (M, M, 3)

    # 2. Reshape to (N_f, N_q, N_f, N_q, 3) and weight
    grad_G = grad_prime.reshape(N_f, N_q, N_f, N_q, 3)
    ww = quad_wts[:, :, None, None] * quad_wts[None, None, :, :]
    grad_Gw = grad_G * ww[..., None]  # (N_f, N_q, N_f, N_q, 3)

    # 3. For each source edge b: cross(∇'g, f_b) → dot with field f
    #    Loop over b (3 iterations, unrolled by JIT)
    D_local = jnp.zeros((N_f, 3, N_f, 3), dtype=jnp.complex128)

    for b in range(3):
        # f_b at source quad points: (N_f, N_q, 3)
        f_b = f_vals[:, b, :, :]

        # cross(∇'g_w, f_b): (N_f,N_q,N_f,N_q,3) × (1,1,N_f,N_q,3)
        curl = jnp.cross(grad_Gw, f_b[None, None, :, :, :])  # (N_f,N_q,N_f,N_q,3)

        # Sum over source quad p → (N_f, N_q, N_f, 3)
        curl_sum = jnp.sum(curl, axis=3)

        # Contract with field f over (q, xyz) → D_b[i,a,j]
        D_b = jnp.einsum('iaqx,iqjx->iaj', f_vals, curl_sum)

        D_local = D_local.at[:, :, :, b].set(D_b)

    # 4. Scatter to global DOF indices
    row = jnp.broadcast_to(face_edges[:, :, None, None], D_local.shape)
    col = jnp.broadcast_to(face_edges[None, None, :, :], D_local.shape)

    D = jnp.zeros((n_edges, n_edges), dtype=jnp.complex128)
    D = D.at[row.ravel(), col.ravel()].add(D_local.ravel())

    return D
