"""BEM system matrix assembly for the quasistatic limit.

The quasistatic BEM solves for surface charges σ on the particle boundary.
For a particle with permittivity ε_in in a medium ε_out, the boundary
integral equation is:

    Λ(ω) σ = -∂φ_inc/∂n

where Λ = (1/2)I + [(ε_in+ε_out)/(ε_in-ε_out)] F

and F is the double-layer operator (normal derivative of Green's function).

Reference: García de Abajo, Phys. Rev. B 65, 115418 (2002), Appendix.
Hohenester & Trügler, CPC 183, 370 (2012).
"""

import numpy as np

from nanobem.mesh.boundary import BoundaryMesh
from nanobem.bem.green import green_normal_derivative_matrix


def build_system_matrix(
    mesh: BoundaryMesh,
    eps_in: complex,
    eps_out: complex,
) -> np.ndarray:
    """Build the BEM system matrix Λ for the quasistatic problem.

    Λ = Λ(ω) I + F

    where Λ(ω) = (ε_in + ε_out) / (2(ε_in - ε_out))
    and F is the double-layer operator matrix.

    The system to solve is: Λ σ = -∂φ_inc/∂n

    Args:
        mesh: boundary mesh
        eps_in: permittivity inside the particle
        eps_out: permittivity of the surrounding medium

    Returns:
        system_matrix: (N_f, N_f) complex matrix
    """
    F = green_normal_derivative_matrix(mesh)

    # Spectral parameter
    lambda_w = (eps_in + eps_out) / (2.0 * (eps_in - eps_out))

    # System matrix: Λ·I + F
    # Note: F already contains the -1/2 self-term on the diagonal,
    # so the total diagonal is lambda_w - 1/2
    n = mesh.n_faces
    system = lambda_w * np.eye(n) + F

    return system


def incident_field_planewave(
    mesh: BoundaryMesh,
    polarization: np.ndarray,
) -> np.ndarray:
    """Compute ∂φ_inc/∂n for a uniform (quasistatic) plane wave.

    In the quasistatic limit, the incident field is uniform:
    E_inc = E_0 (constant vector)
    φ_inc = -E_0 · r
    ∂φ_inc/∂n = -E_0 · n

    Args:
        mesh: boundary mesh
        polarization: E-field polarization direction (3,), will be normalized

    Returns:
        dphi_dn: (N_f,) normal derivative of incident potential at each face
    """
    polarization = np.asarray(polarization, dtype=float)
    polarization = polarization / np.linalg.norm(polarization)

    # ∂φ_inc/∂n = -E_0 · n_face
    normals = mesh.face_normals
    return -np.dot(normals, polarization)
