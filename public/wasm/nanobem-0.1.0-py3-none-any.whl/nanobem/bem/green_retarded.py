"""Retarded scalar Green's function for the Helmholtz equation.

    g(r, r') = exp(ik|r - r'|) / (4π|r - r'|)

and its gradient with respect to r:

    ∇g = (ik - 1/R) · (r - r')/R · g(r, r')

For k = 0, reduces to the electrostatic Green's function 1/(4πR).

Reference: Hohenester et al., CPC 276, 108337 (2022), Eq. (A.3).
"""

import numpy as np


def green_scalar(
    r: np.ndarray,
    r_prime: np.ndarray,
    k: float | complex,
) -> complex:
    """Scalar retarded Green's function g(r, r').

    Args:
        r: field point(s), shape (..., 3)
        r_prime: source point(s), shape (..., 3)
        k: wavenumber (real or complex)

    Returns:
        g: complex value(s), same batch shape as input
    """
    R_vec = r - r_prime
    R = np.linalg.norm(R_vec, axis=-1)
    # Avoid division by zero
    R_safe = np.where(R == 0, 1.0, R)
    g = np.exp(1j * k * R) / (4 * np.pi * R_safe)
    # Zero out self-interaction (R=0) — handled separately
    g = np.where(R == 0, 0.0, g)
    return g


def green_gradient(
    r: np.ndarray,
    r_prime: np.ndarray,
    k: float | complex,
) -> np.ndarray:
    """Gradient of g with respect to r.

    ∇_r g = (ik - 1/R) · (r - r') / R · g(r, r')

    Args:
        r: field point, shape (..., 3)
        r_prime: source point, shape (..., 3)
        k: wavenumber

    Returns:
        grad_g: shape (..., 3), complex
    """
    R_vec = r - r_prime
    R = np.linalg.norm(R_vec, axis=-1, keepdims=True)
    R_safe = np.where(R == 0, 1.0, R)

    g = np.exp(1j * k * R) / (4 * np.pi * R_safe)
    grad_g = (1j * k - 1.0 / R_safe) * R_vec / R_safe * g

    # Zero out self-interaction
    grad_g = np.where(R == 0, 0.0, grad_g)
    return grad_g
