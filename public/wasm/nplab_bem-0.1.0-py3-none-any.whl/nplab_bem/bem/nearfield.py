"""Near-field evaluation of scattered EM fields.

Given the PMCHWT solution (u_E, u_H) on the surface, evaluates the
scattered fields at arbitrary observation points using the Stratton-Chu
representation:

    E_sca(r) = ik₀ [S₂]{u_H}(r) + [D₂]{u_E}(r)

where:
    [S_j u](r) = ∫ g_j(r,s') u(s') dS' + (1/k_j²) ∇_r ∫ g_j(r,s') ∇'·u(s') dS'
    [D_j u](r) = ∫ ∇_r g_j(r,s') × u(s') dS'

Reference: Hohenester et al., CPC 276, 108337 (2022), Eq. (A.10).
"""

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh
from nplab_bem.mesh.raviart_thomas import evaluate_rt


def scattered_field(
    mesh: BoundaryMesh,
    edges_info: dict,
    u_E: np.ndarray,
    u_H: np.ndarray,
    obs_points: np.ndarray,
    k0: float,
    eps_medium: float,
    quad_order: int = 4,
) -> np.ndarray:
    """Evaluate scattered E field at observation points (exterior).

    Uses the exterior Green's function g₂ with k₂ = k₀√ε_m.

    Args:
        mesh: boundary mesh
        edges_info: edge topology from extract_edges()
        u_E: (n_edges,) tangential E DOFs from PMCHWT solution
        u_H: (n_edges,) tangential Z₀H DOFs from PMCHWT solution
        obs_points: (N_obs, 3) observation points in the exterior
        k0: free-space wavenumber (nm⁻¹)
        eps_medium: medium permittivity
        quad_order: surface quadrature order

    Returns:
        E_sca: (N_obs, 3) complex scattered electric field
    """
    n_edges = edges_info["n_edges"]
    face_edges = edges_info["face_edges"]  # (N_f, 3)

    n_medium = np.sqrt(eps_medium + 0j)
    k2 = k0 * np.real(n_medium)

    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    f_vals, div_f = evaluate_rt(mesh, edges_info, quad_pts)
    # f_vals: (N_f, 3, N_q, 3), div_f: (N_f, 3)

    N_obs = obs_points.shape[0]
    N_f, N_q = quad_pts.shape[:2]

    # --- Green's function and gradient at all (obs, face, quad) pairs ---
    # diff = r - s': (N_obs, N_f, N_q, 3)
    diff = obs_points[:, None, None, :] - quad_pts[None, :, :, :]
    R = np.linalg.norm(diff, axis=3)  # (N_obs, N_f, N_q)
    R_safe = np.maximum(R, 1e-30)

    # g₂(r,s') = exp(ik₂R)/(4πR)
    g = np.exp(1j * k2 * R) / (4 * np.pi * R_safe)
    g = np.where(R < 1e-15, 0.0 + 0j, g)  # (N_obs, N_f, N_q)

    # ∇_r g₂ = (ik₂ - 1/R)(r-s')/R × g → (N_obs, N_f, N_q, 3)
    coeff = (1j * k2 - 1.0 / R_safe)
    grad_g = coeff[:, :, :, None] * diff / R_safe[:, :, :, None] * g[:, :, :, None]
    grad_g = np.where(R[:, :, :, None] < 1e-15, 0.0, grad_g)

    # --- Weighted by quadrature ---
    gw = g * quad_wts[None, :, :]  # (N_obs, N_f, N_q)
    grad_gw = grad_g * quad_wts[None, :, :, None]  # (N_obs, N_f, N_q, 3)

    # --- Surface integrals per local (face, edge) ---
    # SL_vec[o,f,a,x] = Σ_q gw[o,f,q] * f_vals[f,a,q,x]
    SL_vec_local = np.einsum('ofq,faqx->ofax', gw, f_vals)

    # SL_div_grad[o,f,a,x] = Σ_q grad_gw[o,f,q,x] * div_f[f,a]
    SL_div_local = np.einsum('ofqx,fa->ofax', grad_gw, div_f)

    # DL[o,f,a,x] = Σ_q (grad_gw[o,f,q,:] × f_vals[f,a,q,:])_x
    curl = np.cross(
        grad_gw[:, :, None, :, :],   # (N_obs, N_f, 1, N_q, 3)
        f_vals[None, :, :, :, :],     # (1, N_f, 3, N_q, 3)
    )  # (N_obs, N_f, 3, N_q, 3)
    DL_local = np.sum(curl, axis=3)  # (N_obs, N_f, 3, 3)

    # --- Scatter local → global edge index ---
    SL_vec = np.zeros((N_obs, n_edges, 3), dtype=complex)
    SL_div = np.zeros((N_obs, n_edges, 3), dtype=complex)
    DL = np.zeros((N_obs, n_edges, 3), dtype=complex)

    for a in range(3):
        np.add.at(SL_vec, (slice(None), face_edges[:, a]), SL_vec_local[:, :, a, :])
        np.add.at(SL_div, (slice(None), face_edges[:, a]), SL_div_local[:, :, a, :])
        np.add.at(DL, (slice(None), face_edges[:, a]), DL_local[:, :, a, :])

    # --- Assemble E_sca ---
    # E_sca(r) = ik₀ [S₂]{u_H}(r) + [D₂]{u_E}(r)
    # [S₂]{u_H} = Σ_ν u_H_ν [SL_vec_ν + (1/k₂²) SL_div_ν]
    # [D₂]{u_E} = Σ_ν u_E_ν DL_ν

    # SL potential: (N_obs, 3)
    SL_pot = np.einsum('oex,e->ox', SL_vec + SL_div / (k2 ** 2), u_H)

    # DL potential: (N_obs, 3)
    DL_pot = np.einsum('oex,e->ox', DL, u_E)

    E_sca = 1j * k0 * SL_pot + DL_pot

    return E_sca


def surface_fields(
    mesh: BoundaryMesh,
    edges_info: dict,
    u_E: np.ndarray,
    u_H: np.ndarray,
    k0: float,
    eps_medium: float,
    polarization: np.ndarray,
    direction: np.ndarray,
    offset: float = 1.0,
    quad_order: int = 4,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute total E field and enhancement at face centroids.

    Evaluates E_total = E_inc + E_sca at points offset outward from
    each face centroid by `offset` nm along the outward normal.

    Args:
        mesh: boundary mesh
        edges_info: edge topology
        u_E, u_H: PMCHWT solution DOFs
        k0: free-space wavenumber (nm⁻¹)
        eps_medium: medium permittivity
        polarization: (3,) incident E-field polarization
        direction: (3,) propagation direction
        offset: distance (nm) outward from surface for evaluation
        quad_order: quadrature order

    Returns:
        E_total: (N_faces, 3) complex total electric field per face
        enhancement: (N_faces,) field enhancement |E_total|/|E_inc|
    """
    pol = np.asarray(polarization, dtype=float)
    dir_vec = np.asarray(direction, dtype=float)
    dir_vec = dir_vec / np.linalg.norm(dir_vec)

    n_m = np.sqrt(eps_medium)
    k_out = k0 * n_m

    # Observation points: face centroids + offset along outward normal
    obs = mesh.face_centroids + offset * mesh.face_normals

    # Scattered field
    E_sca = scattered_field(
        mesh, edges_info, u_E, u_H, obs, k0, eps_medium, quad_order
    )

    # Incident planewave
    phase = np.exp(1j * k_out * (obs @ dir_vec))  # (N_f,)
    E_inc = pol[np.newaxis, :] * phase[:, np.newaxis]  # (N_f, 3)

    E_total = E_inc + E_sca
    enhancement = np.linalg.norm(E_total, axis=1)  # |E_total| / |E_inc|=1

    return E_total, enhancement
