"""BEM solvers — quasistatic and retarded.

Quasistatic: solve for surface charges σ, compute polarizability and C_ext.
Retarded: solve PMCHWT system for tangential fields u_E, u_H, compute C_ext.

References:
- Hohenester & Trügler, CPC 183, 370 (2012) — quasistatic
- Hohenester et al., CPC 276, 108337 (2022) — retarded (Galerkin/RT)
"""

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh
from nplab_bem.bem.assembly import build_system_matrix, incident_field_planewave


def solve_static(
    mesh: BoundaryMesh,
    eps_in: complex,
    eps_out: complex,
    polarization: np.ndarray,
) -> np.ndarray:
    """Solve the quasistatic BEM for surface charges.

    Solves: Λ σ = -∂φ_inc/∂n

    Args:
        mesh: boundary mesh
        eps_in: particle permittivity
        eps_out: medium permittivity
        polarization: incident E-field direction (3,)

    Returns:
        sigma: surface charge density at each face (N_f,)
    """
    system = build_system_matrix(mesh, eps_in, eps_out)
    rhs = -incident_field_planewave(mesh, polarization)
    sigma = np.linalg.solve(system, rhs)
    return sigma


def polarizability(
    mesh: BoundaryMesh,
    eps_particle: complex,
    eps_medium: float = 1.0,
) -> np.ndarray:
    """Compute the polarizability tensor of a particle.

    α_ij = ∫ r_i σ_j(r) dA

    where σ_j is the surface charge for incident field along direction j.

    Args:
        mesh: boundary mesh
        eps_particle: complex permittivity of particle
        eps_medium: permittivity of surrounding medium

    Returns:
        alpha: (3, 3) complex polarizability tensor
    """
    alpha = np.zeros((3, 3), dtype=complex)
    centroids = mesh.face_centroids
    areas = mesh.face_areas

    for j in range(3):
        pol = np.zeros(3)
        pol[j] = 1.0
        sigma = solve_static(mesh, eps_particle, eps_medium, pol)

        # α_ij = Σ_k centroid_k[i] × σ_k × A_k
        for i in range(3):
            alpha[i, j] = np.sum(centroids[:, i] * sigma * areas)

    return alpha


def extinction_cross_section(
    mesh: BoundaryMesh,
    eps_particle: complex,
    eps_medium: float,
    k0: float,
) -> float:
    """Compute extinction cross section in the quasistatic limit.

    C_ext = k₀/ε_m × Im(Tr(α)/3)

    For unpolarized light (average over polarizations).

    Args:
        mesh: boundary mesh
        eps_particle: complex permittivity of particle
        eps_medium: real permittivity of medium
        k0: free-space wavenumber (2π/λ)

    Returns:
        c_ext: extinction cross section (same units² as mesh coordinates)
    """
    alpha = polarizability(mesh, eps_particle, eps_medium)
    alpha_avg = np.trace(alpha) / 3.0  # isotropic average

    # C_ext = k₀ × Im(α) / ε_m (in Gaussian units, but we use SI-adjacent)
    # Actually: C_ext = k₀ × Im(α) for a sphere in vacuum
    # With medium: C_ext = k₀ √ε_m × Im(α) / ε_m = k₀ Im(α) / √ε_m
    # For simplicity and consistency with Mie: C_ext = k₀ × Im(α)
    c_ext = k0 * np.imag(alpha_avg)

    return float(c_ext)


# --- Retarded BEM solver ---


def extinction_cross_section_retarded(
    mesh: BoundaryMesh,
    eps_particle: complex,
    eps_medium: float,
    k0: float,
    quad_order: int = 4,
) -> float:
    """Compute extinction cross section using retarded (full Maxwell) BEM.

    Solves the PMCHWT system for three orthogonal polarizations and
    returns the orientation-averaged extinction cross section via
    the optical theorem:

        C_ext = -1/|E₀|² Re(q_inc^H · u)

    averaged over polarizations.

    Args:
        mesh: boundary mesh (sphere or other shape)
        eps_particle: complex permittivity of particle
        eps_medium: real permittivity of medium
        k0: free-space wavenumber 2π/λ (nm⁻¹)
        quad_order: quadrature order for Galerkin integration

    Returns:
        c_ext: extinction cross section (nm²)
    """
    from nplab_bem.bem.assembly_retarded import build_retarded_system
    from nplab_bem.bem.excitation import planewave_rhs
    from nplab_bem.mesh.edges import extract_edges

    # Build system matrix (same for all polarizations)
    A, edges_info = build_retarded_system(
        mesh, eps_particle, eps_medium, k0, quad_order,
        use_duffy=True, n_duffy=4, refine_touching=False,
    )

    # Propagation along z
    direction = np.array([0.0, 0.0, 1.0])
    n_medium = np.sqrt(eps_medium + 0j)
    k_out = k0 * np.real(n_medium)

    # Average over x and y polarizations (z is propagation direction)
    polarizations = [
        np.array([1.0, 0.0, 0.0]),
        np.array([0.0, 1.0, 0.0]),
    ]

    c_ext_total = 0.0
    for pol in polarizations:
        q_inc = planewave_rhs(
            mesh, edges_info, pol, direction, k0, eps_medium, quad_order
        )
        u = np.linalg.solve(A, q_inc)

        # Extinction via optical theorem with full far field (SL + DL):
        # C_ext = (4π/k₂) Im(pol · E_far)
        # E_far = ik₀μ/(4π) V_H + ik₂/(4π) dir × V_E
        # where V_H = Σ u_H_ν F_ν, V_E = Σ u_E_ν F_ν
        # F_ν = ∫ f_ν(s) exp(-ik₂ dir·s) dS = conj of incident projection
        n = len(q_inc) // 2
        u_E = u[:n]
        u_H = u[n:]

        # F_ν from the incident field projections
        from nplab_bem.mesh.raviart_thomas import evaluate_rt
        quad_pts_loc, quad_wts_loc = mesh.quadrature(order=quad_order)
        f_vals_loc, _ = evaluate_rt(mesh, edges_info, quad_pts_loc)
        face_edges_loc = edges_info["face_edges"]

        F = np.zeros((n, 3), dtype=complex)
        for i_f in range(mesh.n_faces):
            for a_loc in range(3):
                nu_loc = face_edges_loc[i_f, a_loc]
                for iq in range(quad_pts_loc.shape[1]):
                    phase = np.exp(-1j * k_out * np.dot(direction, quad_pts_loc[i_f, iq]))
                    F[nu_loc] += quad_wts_loc[i_f, iq] * f_vals_loc[i_f, a_loc, iq] * phase

        V_H = np.sum(u_H[:, None] * F, axis=0)
        V_E = np.sum(u_E[:, None] * F, axis=0)

        # Far field: SL + DL contributions
        SL_far = 1j * k0 / (4 * np.pi) * V_H
        DL_far = 1j * k_out / (4 * np.pi) * np.cross(direction, V_E)
        E_far = SL_far + DL_far

        c_ext_pol = 4 * np.pi / k_out * np.imag(np.dot(pol, E_far))
        c_ext_total += c_ext_pol

    # Average over the 2 transverse polarizations
    return float(c_ext_total / 2.0)


def scattering_cross_section_retarded(
    mesh: BoundaryMesh,
    eps_particle: complex,
    eps_medium: float,
    k0: float,
    quad_order: int = 4,
    n_theta: int = 10,
    n_phi: int = 20,
) -> float:
    """Compute scattering cross section using retarded BEM.

    Integrates |f_sca(r̂)|² over all solid angles using product
    Gauss-Legendre (θ) × uniform (φ) quadrature on the unit sphere.

    C_sca = (1/2) Σ_pol ∫ |f_sca(r̂; pol)|² dΩ

    where f_sca = ik₀/(4π) V_H + ik_out/(4π) r̂ × V_E is the
    scattering amplitude from the PMCHWT solution.

    Args:
        mesh: boundary mesh
        eps_particle: complex permittivity of particle
        eps_medium: real permittivity of medium
        k0: free-space wavenumber 2π/λ (nm⁻¹)
        quad_order: quadrature order for Galerkin integration
        n_theta: number of Gauss-Legendre points in polar angle
        n_phi: number of uniform points in azimuthal angle

    Returns:
        c_sca: scattering cross section (nm²)
    """
    from nplab_bem.bem.assembly_retarded import build_retarded_system
    from nplab_bem.bem.excitation import planewave_rhs
    from nplab_bem.mesh.raviart_thomas import evaluate_rt

    # Build and solve PMCHWT
    A, edges_info = build_retarded_system(
        mesh, eps_particle, eps_medium, k0, quad_order,
        use_duffy=True, n_duffy=4, refine_touching=False,
    )

    direction = np.array([0.0, 0.0, 1.0])
    n_medium = np.sqrt(eps_medium + 0j)
    k_out = k0 * np.real(n_medium)
    n = edges_info["n_edges"]
    face_edges = edges_info["face_edges"]

    # Quadrature data for far-field projections
    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    f_vals, _ = evaluate_rt(mesh, edges_info, quad_pts)

    # Unit sphere quadrature: Gauss-Legendre (θ) × uniform (φ)
    cos_theta, w_theta = np.polynomial.legendre.leggauss(n_theta)
    phi = np.linspace(0, 2 * np.pi, n_phi, endpoint=False)
    d_phi = 2 * np.pi / n_phi

    dirs = []
    w_sphere = []
    for i in range(n_theta):
        sin_th = np.sqrt(1 - cos_theta[i] ** 2)
        for j in range(n_phi):
            dirs.append([sin_th * np.cos(phi[j]),
                         sin_th * np.sin(phi[j]),
                         cos_theta[i]])
            w_sphere.append(w_theta[i] * d_phi)

    dirs = np.array(dirs)       # (N_dir, 3)
    w_sphere = np.array(w_sphere)  # (N_dir,)
    n_dir = len(dirs)

    # Vectorized F_ν(r̂) for all directions at once:
    # phase[d,f,q] = exp(-ik_out * dir[d] · s[f,q])
    phase = np.exp(-1j * k_out * np.einsum('dx,fqx->dfq', dirs, quad_pts))

    # F_local[d,f,a,x] = Σ_q f[f,a,q,x] * phase[d,f,q] * w[f,q]
    F_local = np.einsum('faqx,dfq,fq->dfax', f_vals, phase, quad_wts)

    # Scatter to global edge DOFs: F[d, ν, xyz]
    F = np.zeros((n_dir, n, 3), dtype=complex)
    for a in range(3):
        np.add.at(F, (slice(None), face_edges[:, a]), F_local[:, :, a, :])

    # Solve for each polarization and integrate |f_sca|²
    polarizations = [np.array([1., 0., 0.]), np.array([0., 1., 0.])]
    c_sca_total = 0.0

    for pol in polarizations:
        q_inc = planewave_rhs(
            mesh, edges_info, pol, direction, k0, eps_medium, quad_order
        )
        u = np.linalg.solve(A, q_inc)
        u_E = u[:n]
        u_H = u[n:]

        # V_H, V_E for all directions: (N_dir, 3)
        V_H = np.einsum('dex,e->dx', F, u_H)
        V_E = np.einsum('dex,e->dx', F, u_E)

        # Scattering amplitude: f = ik₀/(4π) V_H_⊥ + ik_out/(4π) r̂ × V_E
        # V_H_⊥ = V_H - r̂(r̂·V_H) is the transverse projection
        # (DL term r̂ × V_E is already transverse)
        rdot_VH = np.sum(dirs * V_H, axis=1, keepdims=True)  # (N_dir, 1)
        V_H_perp = V_H - dirs * rdot_VH  # (N_dir, 3)
        SL = 1j * k0 / (4 * np.pi) * V_H_perp
        DL = 1j * k_out / (4 * np.pi) * np.cross(dirs, V_E)
        f_sca = SL + DL  # (N_dir, 3)

        # C_sca = ∫ |f_sca|² dΩ
        f_sca_sq = np.sum(np.abs(f_sca) ** 2, axis=1)  # (N_dir,)
        c_sca_total += np.sum(f_sca_sq * w_sphere)

    # Average over 2 polarizations
    return float(c_sca_total / 2.0)


def purcell_factor(
    mesh: BoundaryMesh,
    eps_particle: complex,
    eps_medium: float,
    k0: float,
    dipole_position: np.ndarray,
    dipole_moment: np.ndarray,
    quad_order: int = 4,
) -> float:
    """Compute the Purcell factor for a dipole near a particle.

    F_P = 1 + (6π/k₂³) Im(p̂ · E_sca(r₀))

    where E_sca is the scattered field at the dipole position r₀
    when the system is excited by the dipole with moment p.
    The E_inc convention is E_dip = (k₂²I + ∇∇)g · p (unnormalized
    dyadic Green's function), so the 1/(ε₀ε_m) prefactor cancels
    between numerator and denominator.

    Args:
        mesh: boundary mesh
        eps_particle: complex permittivity of particle
        eps_medium: real permittivity of medium
        k0: free-space wavenumber (nm⁻¹)
        dipole_position: (3,) location of the dipole (outside the particle)
        dipole_moment: (3,) dipole moment direction and magnitude
        quad_order: quadrature order

    Returns:
        F_P: Purcell enhancement factor (dimensionless, ≥ 0)
    """
    from nplab_bem.bem.assembly_retarded import build_retarded_system
    from nplab_bem.bem.excitation import dipole_rhs
    from nplab_bem.bem.nearfield import scattered_field

    r0 = np.asarray(dipole_position, dtype=float)
    p = np.asarray(dipole_moment, dtype=complex)
    p_hat = p / np.linalg.norm(p)

    n_medium = np.sqrt(eps_medium + 0j)
    k_out = k0 * np.real(n_medium)

    # Solve PMCHWT
    A, edges_info = build_retarded_system(
        mesh, eps_particle, eps_medium, k0, quad_order,
        use_duffy=True, n_duffy=4, refine_touching=False,
    )
    n = edges_info["n_edges"]

    q_inc = dipole_rhs(mesh, edges_info, r0, p_hat, k0, eps_medium, quad_order)
    u = np.linalg.solve(A, q_inc)

    # Evaluate scattered field at the dipole position
    E_sca = scattered_field(
        mesh, edges_info, u[:n], u[n:],
        r0[np.newaxis, :], k0, eps_medium, quad_order,
    )

    # Purcell factor: F_P = 1 + (6π/k₂³) Im(p̂* · E_sca)
    fp = 1.0 + (6 * np.pi / k_out**3) * np.imag(np.dot(np.conj(p_hat), E_sca[0]))

    return float(fp)


def eels_loss_probability(
    mesh: BoundaryMesh,
    eps_particle: complex,
    eps_medium: float,
    k0: float,
    beam_position: np.ndarray,
    beam_direction: np.ndarray,
    beta: float,
    quad_order: int = 4,
    n_z: int = 50,
    z_range: float | None = None,
) -> float:
    """Compute the EELS loss probability Γ(ω) for a swift electron.

    Solves the PMCHWT system with the electron beam excitation, evaluates
    the scattered field along the trajectory, and integrates:

        Γ_red(ω) = (1/v) Im ∫ E_sca‖(z) exp(-iqz) dz

    The result is in reduced units — multiply by e²/(πℏωε₀ε_m) for
    physical probability.

    Reference: García de Abajo & Howie, PRB 65, 115418 (2002), Eq. (4).

    Args:
        mesh: boundary mesh
        eps_particle: complex permittivity of particle
        eps_medium: real permittivity of medium
        k0: free-space wavenumber (nm⁻¹)
        beam_position: (3,) point the beam passes through
        beam_direction: (3,) beam propagation direction
        beta: v/c ratio (0 < β < 1)
        quad_order: quadrature order
        n_z: number of integration points along trajectory
        z_range: half-length of integration window (nm), auto if None

    Returns:
        gamma: reduced EELS loss probability (positive for energy loss)
    """
    from nplab_bem.bem.assembly_retarded import build_retarded_system
    from nplab_bem.bem.excitation import ebeam_rhs
    from nplab_bem.bem.nearfield import scattered_field

    r_beam = np.asarray(beam_position, dtype=float)
    d_hat = np.asarray(beam_direction, dtype=float)
    d_hat = d_hat / np.linalg.norm(d_hat)

    q = k0 / beta
    qm = k0 * np.sqrt(max(1.0 / beta**2 - eps_medium, 0.0))

    # Auto z_range: 5× decay length of evanescent field
    if z_range is None:
        z_range = 5.0 / max(qm, 1e-6)

    # Solve PMCHWT
    A, edges_info = build_retarded_system(
        mesh, eps_particle, eps_medium, k0, quad_order,
        use_duffy=True, n_duffy=4, refine_touching=False,
    )
    n = edges_info["n_edges"]

    q_inc = ebeam_rhs(
        mesh, edges_info, r_beam, d_hat, beta, k0, eps_medium, quad_order
    )
    u = np.linalg.solve(A, q_inc)

    # Evaluate E_sca along the trajectory
    z_pts, z_wts = np.polynomial.legendre.leggauss(n_z)
    z_pts = z_pts * z_range  # map [-1,1] → [-z_range, z_range]
    z_wts = z_wts * z_range

    obs_pts = r_beam[np.newaxis, :] + z_pts[:, np.newaxis] * d_hat[np.newaxis, :]

    E_sca = scattered_field(
        mesh, edges_info, u[:n], u[n:],
        obs_pts, k0, eps_medium, quad_order,
    )

    # Parallel component of E_sca along beam direction
    E_par = np.sum(E_sca * d_hat[np.newaxis, :], axis=1)  # (n_z,) complex

    # Integrate: Im ∫ E_par(z) exp(-iqz) dz
    integrand = E_par * np.exp(-1j * q * z_pts)
    gamma = np.imag(np.sum(integrand * z_wts))

    return float(gamma)
