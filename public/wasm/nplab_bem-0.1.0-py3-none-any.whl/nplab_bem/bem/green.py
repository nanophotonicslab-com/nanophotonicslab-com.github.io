"""Electrostatic Green's function for BEM.

G(r,r') = 1 / (4π|r-r'|)
∂G/∂n'  = -(r-r')·n' / (4π|r-r'|³)

For self-interaction (diagonal) terms, analytical results for
flat triangular elements are used.

Reference: Hohenester & Trügler, Comput. Phys. Commun. 183, 370 (2012).
"""

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh


def green_matrix(mesh: BoundaryMesh) -> np.ndarray:
    """Build the Green's function matrix G_ij.

    G_ij = ∫∫ G(r,r') dA_i dA_j ≈ A_i · A_j · G(c_i, c_j) for i≠j

    For centroid-based collocation with constant basis functions.
    Self-terms use the analytical result for a flat triangle.

    Args:
        mesh: boundary mesh

    Returns:
        G: (N_f, N_f) Green's function matrix
    """
    centroids = mesh.face_centroids  # (N, 3)
    areas = mesh.face_areas  # (N,)
    n = mesh.n_faces

    # Pairwise distances between centroids
    diff = centroids[:, np.newaxis, :] - centroids[np.newaxis, :, :]  # (N, N, 3)
    dist = np.linalg.norm(diff, axis=2)  # (N, N)

    # Off-diagonal: G_ij = A_j / (4π|r_i - r_j|)
    # (collocation: evaluate at centroid i, integrate over face j)
    with np.errstate(divide="ignore", invalid="ignore"):
        G = areas[np.newaxis, :] / (4 * np.pi * dist)

    # Self-term: analytical result for a flat triangle
    # G_ii ≈ A_i / (4π) × (2/√(A_i/π)) ≈ √(A_i/π) / (2π)
    # This is the average of 1/|r-r'| over a triangle of area A,
    # approximated by the equivalent circle of same area.
    for i in range(n):
        r_eq = np.sqrt(areas[i] / np.pi)  # equivalent radius
        G[i, i] = areas[i] / (4 * np.pi) * 2 / r_eq

    return G


def green_normal_derivative_matrix(mesh: BoundaryMesh) -> np.ndarray:
    """Build the adjoint double-layer operator K* matrix.

    K*_ij = A_j · n_i · (c_j - c_i) / (4π|c_i - c_j|³)  for i≠j

    This is ∂G/∂n evaluated at the field point c_i (not the source).
    Self-term K*_ii = 0 for flat elements (∇G is tangential to the
    element at its own centroid, so n·∇G = 0).

    Args:
        mesh: boundary mesh

    Returns:
        K: (N_f, N_f) adjoint double-layer operator matrix
    """
    centroids = mesh.face_centroids  # (N, 3)
    normals = mesh.face_normals  # (N, 3)
    areas = mesh.face_areas  # (N,)
    n = mesh.n_faces

    # c_j - c_i vectors
    diff = centroids[np.newaxis, :, :] - centroids[:, np.newaxis, :]  # (N, N, 3)
    dist = np.linalg.norm(diff, axis=2)  # (N, N)
    dist3 = dist**3

    # n_i · (c_j - c_i)
    dot_ni = np.sum(normals[:, np.newaxis, :] * diff, axis=2)  # (N, N)

    # K*_ij = A_j · n_i · (c_j - c_i) / (4π|c_i - c_j|³)
    with np.errstate(divide="ignore", invalid="ignore"):
        K = areas[np.newaxis, :] * dot_ni / (4 * np.pi * dist3)

    # Self-term: 0 for flat elements
    np.fill_diagonal(K, 0.0)

    return K
