"""Singular integration for Galerkin BEM over triangle pairs.

Classifies triangle pairs by distance and provides quadrature rules
for near-singular and singular (touching/identical) integrals.

Three regimes (Hohenester 2022, Fig. B.8, Appendix B.3):
1. Far pairs (d > relcutoff): standard quadrature
2. Close pairs (d < relcutoff): refined higher-order quadrature
3. Touching/identical: Duffy-type integration

The Duffy transform regularizes the 1/R singularity by splitting
the 4D domain T×T into sub-regions and applying polar-like coordinates
that produce a Jacobian factor cancelling the singularity.

Distance measure (Eq. B.3):
    d(τ₁, τ₂) = ||pos(τ₁) - pos(τ₂)|| / (rad(τ₁) + rad(τ₂))

References:
- Taylor (2003), IEEE TAP 51(7) — Duffy for EFIE
- Sauter & Schwab, "Boundary Element Methods", Ch. 5
"""

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh


def triangle_bounding_radii(mesh: BoundaryMesh) -> np.ndarray:
    """Bounding sphere radius for each triangle.

    rad(τ) = max distance from centroid to any vertex of τ.

    Returns:
        radii: (N_faces,) bounding radii
    """
    triangles = mesh._mesh.triangles  # (N_f, 3, 3)
    centroids = mesh.face_centroids  # (N_f, 3)
    dists = np.linalg.norm(
        triangles - centroids[:, np.newaxis, :], axis=2
    )  # (N_f, 3)
    return np.max(dists, axis=1)


def classify_triangle_pairs(
    mesh: BoundaryMesh,
    relcutoff: float = 2.0,
) -> dict:
    """Classify triangle pairs by relative distance.

    Args:
        mesh: boundary mesh
        relcutoff: distance threshold for refined integration

    Returns:
        dict with keys: distances, identical, touching, close, far
    """
    centroids = mesh.face_centroids
    radii = triangle_bounding_radii(mesh)
    n = mesh.n_faces

    diff = centroids[:, np.newaxis, :] - centroids[np.newaxis, :, :]
    dist = np.linalg.norm(diff, axis=2)
    rad_sum = radii[:, np.newaxis] + radii[np.newaxis, :]
    rel_dist = dist / rad_sum

    faces = mesh.faces
    touching_mask = np.zeros((n, n), dtype=bool)
    for i in range(n):
        for j in range(i + 1, n):
            if len(set(faces[i]) & set(faces[j])) > 0:
                touching_mask[i, j] = True
                touching_mask[j, i] = True

    identical = list(range(n))
    touching = list(zip(*np.where(np.triu(touching_mask, k=1))))
    close_mask = (rel_dist < relcutoff) & ~touching_mask & ~np.eye(n, dtype=bool)
    close = list(zip(*np.where(np.triu(close_mask, k=1))))
    far_mask = (rel_dist >= relcutoff)
    far = list(zip(*np.where(np.triu(far_mask, k=1))))

    return {
        "distances": rel_dist,
        "identical": identical,
        "touching": touching,
        "close": close,
        "far": far,
    }


# ---------------------------------------------------------------------------
# Duffy transform for self-interaction on identical triangles
# ---------------------------------------------------------------------------


def _gauss_legendre_01(n: int) -> tuple[np.ndarray, np.ndarray]:
    """Gauss-Legendre quadrature on [0, 1]."""
    pts, wts = np.polynomial.legendre.leggauss(n)
    # Map from [-1,1] to [0,1]
    pts = 0.5 * (pts + 1)
    wts = 0.5 * wts
    return pts, wts


def self_interaction_static(
    triangle: np.ndarray,
    n_duffy: int = 4,
) -> float:
    """Compute the static self-interaction integral on a single triangle.

    I = ∫_T ∫_T 1/(4π|s-s'|) dS dS'

    Uses Duffy-type polar coordinates to regularize the 1/R singularity.
    For each outer quadrature point s, the inner integral is transformed
    to polar coordinates centered at s, where the Jacobian ρ cancels 1/ρ.

    Args:
        triangle: (3, 3) vertex positions
        n_duffy: number of Gauss-Legendre points per dimension

    Returns:
        I: the self-interaction integral (positive real scalar)
    """
    v0, v1, v2 = triangle
    e1 = v1 - v0  # edge vectors
    e2 = v2 - v0
    normal = np.cross(e1, e2)
    area = 0.5 * np.linalg.norm(normal)

    # Outer quadrature: standard triangle quadrature
    outer_pts_ref, outer_wts_ref = _triangle_quadrature_7()
    n_outer = len(outer_wts_ref)

    # Gauss-Legendre for the inner Duffy (radial + angular)
    rho_pts, rho_wts = _gauss_legendre_01(n_duffy)
    theta_pts, theta_wts = _gauss_legendre_01(2 * n_duffy)
    # Map theta to [0, 2π]
    theta_pts = theta_pts * 2 * np.pi
    theta_wts = theta_wts * 2 * np.pi

    # Build local 2D coordinate system in the triangle plane
    e1_norm = e1 / np.linalg.norm(e1)
    e2_perp = e2 - np.dot(e2, e1_norm) * e1_norm
    e2_norm = e2_perp / np.linalg.norm(e2_perp)

    I_total = 0.0
    for i_out in range(n_outer):
        u_out, v_out = outer_pts_ref[i_out]
        w_out = outer_wts_ref[i_out] * 2 * area  # map from ref to physical

        # Physical position of outer point
        s = v0 + u_out * e1 + v_out * e2

        # Project s into 2D local coordinates
        ds = s - v0
        s_2d = np.array([np.dot(ds, e1_norm), np.dot(ds, e2_norm)])

        # For each angle θ, find max radius ρ_max (intersection with triangle edges)
        for i_theta in range(len(theta_pts)):
            theta = theta_pts[i_theta]
            w_theta = theta_wts[i_theta]

            direction_2d = np.array([np.cos(theta), np.sin(theta)])
            rho_max = _ray_triangle_intersection_2d(
                s_2d, direction_2d, v0, e1, e2, e1_norm, e2_norm
            )
            if rho_max <= 0:
                continue

            # Inner integral: ∫₀^ρ_max (1/(4πρ)) × ρ dρ = ρ_max/(4π)
            # The Jacobian ρ from polar coords cancels the 1/ρ from 1/R.
            # The integral ∫₀^ρ_max 1 dρ = ρ_max
            I_total += w_out * w_theta * rho_max / (4 * np.pi)

    return I_total


def _ray_triangle_intersection_2d(
    origin_2d: np.ndarray,
    direction_2d: np.ndarray,
    v0: np.ndarray,
    e1: np.ndarray,
    e2: np.ndarray,
    e1_norm: np.ndarray,
    e2_norm: np.ndarray,
) -> float:
    """Find where a ray from origin in direction hits the triangle boundary.

    Works in the 2D local coordinate system of the triangle.
    The triangle in reference coords is: P = v0 + u*e1 + v*e2, 0≤u, 0≤v, u+v≤1.
    In 2D local coords: (x,y) = (u*e1·e1_norm + v*e2·e1_norm, v*e2·e2_norm)

    Returns:
        rho_max: distance to boundary (positive), or 0 if no intersection
    """
    # Triangle vertices in 2D
    v0_2d = np.array([0.0, 0.0])
    v1_2d = np.array([np.dot(e1, e1_norm), np.dot(e1, e2_norm)])
    v2_2d = np.array([np.dot(e2, e1_norm), np.dot(e2, e2_norm)])

    # Three edges of the triangle
    edges = [
        (v0_2d, v1_2d),  # edge 0: v0→v1
        (v1_2d, v2_2d),  # edge 1: v1→v2
        (v2_2d, v0_2d),  # edge 2: v2→v0
    ]

    rho_min_positive = np.inf
    for p_start, p_end in edges:
        t = _ray_segment_intersection(origin_2d, direction_2d, p_start, p_end)
        if t is not None and t > 1e-12:
            rho_min_positive = min(rho_min_positive, t)

    return rho_min_positive if rho_min_positive < np.inf else 0.0


def _ray_segment_intersection(
    origin: np.ndarray,
    direction: np.ndarray,
    p0: np.ndarray,
    p1: np.ndarray,
) -> float | None:
    """Intersect a 2D ray with a line segment.

    Ray: origin + t * direction, t > 0
    Segment: p0 + s * (p1 - p0), 0 ≤ s ≤ 1

    Returns t if intersection exists, None otherwise.
    """
    d = p1 - p0
    denom = direction[0] * d[1] - direction[1] * d[0]
    if abs(denom) < 1e-15:
        return None  # parallel

    dp = p0 - origin
    t = (dp[0] * d[1] - dp[1] * d[0]) / denom
    s = (dp[0] * direction[1] - dp[1] * direction[0]) / denom

    if t > 0 and 0 <= s <= 1:
        return t
    return None


def _triangle_quadrature_7() -> tuple[np.ndarray, np.ndarray]:
    """7-point degree-5 quadrature on reference triangle.

    Weights sum to 0.5 (area of reference triangle).
    """
    a1 = 0.059715871789770
    b1 = 0.470142064105115
    a2 = 0.797426985353087
    b2 = 0.101286507323456
    pts = np.array([
        [1 / 3, 1 / 3],
        [a1, b1], [b1, a1], [b1, b1],
        [a2, b2], [b2, a2], [b2, b2],
    ])
    wts = np.array([
        0.1125,
        0.0629695902724, 0.0629695902724, 0.0629695902724,
        0.0661970763942, 0.0661970763942, 0.0661970763942,
    ])
    # These weights already sum to ~0.5 (reference triangle area). No rescaling.
    return pts, wts


def refined_triangle_quadrature(order: int = 7) -> tuple[np.ndarray, np.ndarray]:
    """Higher-order Gaussian quadrature on reference triangle.

    Returns points and weights on the reference triangle (0,0)-(1,0)-(0,1).
    Weights sum to 0.5 (area of reference triangle).
    """
    if order == 3:
        pts = np.array([[1 / 6, 1 / 6], [2 / 3, 1 / 6], [1 / 6, 2 / 3]])
        wts = np.array([1 / 6, 1 / 6, 1 / 6])
    elif order == 4:
        pts = np.array([
            [1 / 3, 1 / 3], [1 / 5, 1 / 5], [3 / 5, 1 / 5], [1 / 5, 3 / 5]
        ])
        wts = np.array([-27 / 96, 25 / 96, 25 / 96, 25 / 96])
    elif order == 7:
        return _triangle_quadrature_7()
    else:
        raise ValueError(f"Order {order} not available. Use 3, 4, or 7.")
    return pts, wts


# ---------------------------------------------------------------------------
# Singularity subtraction for retarded Green's function
# ---------------------------------------------------------------------------


def self_interaction_green_rt(
    triangle: np.ndarray,
    k: complex,
    f_outer: np.ndarray,
    f_inner: np.ndarray,
    div_outer: float,
    div_inner: float,
    outer_pts_3d: np.ndarray,
    outer_wts: np.ndarray,
    n_duffy: int = 4,
) -> complex:
    """Compute the self-interaction integral for a single-layer element.

    I = ∫_T ∫_T [f_a(s)·f_b(s') - div_a div_b / k²] g(s,s') dS dS'

    Uses singularity subtraction: split g = 1/(4πR) + [g - 1/(4πR)]
    - Static part (singular): Duffy polar quadrature
    - Smooth remainder: standard quadrature (the remainder → ik/(4π) as R→0)

    Args:
        triangle: (3, 3) vertex positions
        k: wavenumber (complex)
        f_outer: (N_out, 3) RT basis values at outer quadrature points
        f_inner: (N_out, 3) RT basis values (for inner = same triangle)
        div_outer: scalar divergence of outer RT basis
        div_inner: scalar divergence of inner RT basis
        outer_pts_3d: (N_out, 3) outer quadrature points in 3D
        outer_wts: (N_out,) outer quadrature weights
        n_duffy: Duffy quadrature order

    Returns:
        I: complex self-interaction integral
    """
    v0, v1, v2 = triangle
    e1 = v1 - v0
    e2 = v2 - v0
    area = 0.5 * np.linalg.norm(np.cross(e1, e2))
    n_outer = len(outer_wts)

    # Build local 2D coordinate system
    e1_norm = e1 / np.linalg.norm(e1)
    e2_perp = e2 - np.dot(e2, e1_norm) * e1_norm
    e2_norm = e2_perp / np.linalg.norm(e2_perp)

    # Gauss-Legendre for Duffy polar coordinates
    rho_pts, rho_wts = _gauss_legendre_01(n_duffy)
    theta_pts_raw, theta_wts_raw = _gauss_legendre_01(2 * n_duffy)
    theta_pts = theta_pts_raw * 2 * np.pi
    theta_wts = theta_wts_raw * 2 * np.pi

    # Precompute f·f' and div terms for the integrand
    div_term = div_outer * div_inner / (k ** 2) if abs(k) > 1e-30 else 0.0

    I_singular = 0.0 + 0j
    I_smooth = 0.0 + 0j

    for i_out in range(n_outer):
        s = outer_pts_3d[i_out]
        w_out = outer_wts[i_out]
        f_a = f_outer[i_out]  # (3,) RT value at outer point

        ds = s - v0
        s_2d = np.array([np.dot(ds, e1_norm), np.dot(ds, e2_norm)])

        for i_theta in range(len(theta_pts)):
            theta = theta_pts[i_theta]
            w_theta = theta_wts[i_theta]
            cos_t, sin_t = np.cos(theta), np.sin(theta)
            direction_2d = np.array([cos_t, sin_t])
            direction_3d = cos_t * e1_norm + sin_t * e2_norm

            rho_max = _ray_triangle_intersection_2d(
                s_2d, direction_2d, v0, e1, e2, e1_norm, e2_norm
            )
            if rho_max <= 1e-15:
                continue

            for i_rho in range(len(rho_pts)):
                rho = rho_pts[i_rho] * rho_max
                w_rho = rho_wts[i_rho] * rho_max

                s_prime = s + rho * direction_3d
                R = rho  # by construction

                # RT basis at s' (approximate using linearity)
                # f_b at s_prime: need to evaluate RT at this point
                # For the static self-term, we use the outer basis
                # For the smooth correction, we use standard quadrature
                f_b = _rt_at_point(s_prime, v0, e1, e2, area,
                                   f_inner, outer_pts_3d, outer_wts, n_outer)

                # Integrand: [f_a · f_b - div_term]
                ff_dot = np.dot(f_a, f_b) - div_term

                # Static part: ff_dot / (4πR) × Jacobian ρ = ff_dot / (4π)
                # (the ρ from Jacobian cancels 1/R = 1/ρ)
                I_singular += w_out * w_theta * w_rho * ff_dot / (4 * np.pi)

                # Smooth part: ff_dot × [exp(ikR) - 1] / (4πR) × ρ dρ
                if R > 1e-15:
                    g_smooth = (np.exp(1j * k * R) - 1) / (4 * np.pi * R)
                else:
                    g_smooth = 1j * k / (4 * np.pi)
                I_smooth += w_out * w_theta * w_rho * ff_dot * g_smooth * rho

    return I_singular + I_smooth


def _rt_at_point(
    point: np.ndarray,
    v0: np.ndarray,
    e1: np.ndarray,
    e2: np.ndarray,
    area: float,
    f_ref_vals: np.ndarray,
    ref_pts: np.ndarray,
    ref_wts: np.ndarray,
    n_ref: int,
) -> np.ndarray:
    """Approximate RT value at an arbitrary point using nearest reference point.

    This is a simple nearest-neighbor interpolation. For better accuracy,
    use direct evaluation of the RT basis.
    """
    # Find nearest reference quadrature point
    dists = np.linalg.norm(ref_pts - point[np.newaxis, :], axis=1)
    nearest = np.argmin(dists)
    return f_ref_vals[nearest]
