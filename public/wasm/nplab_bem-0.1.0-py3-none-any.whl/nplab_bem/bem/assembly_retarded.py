"""Retarded BEM system assembly (PMCHWT formulation).

Builds the 2n × 2n block system from the single-layer (S) and
double-layer (D) potential matrices.

System (Eq. 12):
    ( [[D₁+D₂]]           -iω[[μ₁S₁+μ₂S₂]] ) ( u_E )   ( q_E^inc )
    ( iω[[ε₁S₁+ε₂S₂]]    [[D₁+D₂]]         ) ( u_H ) = ( q_H^inc )

For non-magnetic materials (μ₁ = μ₂ = 1):
    A₁₂ = -iω(S₁ + S₂)
    A₂₁ = iω(ε₁S₁ + ε₂S₂)
    A₁₁ = A₂₂ = D₁ + D₂

Reference: Hohenester et al., CPC 276, 108337 (2022), Eq. (12).
"""

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh
from nplab_bem.mesh.edges import extract_edges
from nplab_bem.bem.potentials import single_layer_matrix, double_layer_matrix


# Speed of light in nm/s (since lengths are in nm, k0 in 1/nm)
# Actually, we work with k0 = 2π/λ and ω = k0 * c.
# But in the matrix, ω appears as: ω = k0 * c where c is in natural units.
# Following the convention of Hohenester et al. (2022), k0 = 2π/λ (nm⁻¹) and ω = k0 (c=1
# in appropriate units), we follow the same convention.
# In SI: ω = c * k0, and the matrix has iω = i*c*k0.
# But S has units of [length] from the Green's function integral,
# and D is dimensionless. So the coupling block iω*S has units of [length/time]...
#
# Convention of Hohenester et al. (2022): all quantities expressed through k0 = 2π/λ.
# The angular frequency ω = c * k0 where c = speed of light.
# In the units where lengths are nm: c ≈ 299792458e9 nm/s.
# That formulation normalizes fields to E0=1, and the system is solved
# per-frequency, so the factor ω appears as k0 * c.
#
# Actually, re-reading the paper: they use SI units with k0 = ω/c.
# So ω = k0 * c. In the matrix blocks:
#   A12 = -iω(μ₁S₁ + μ₂S₂) = -i*k0*c*(S₁ + S₂) for μ=1
#   A21 = +iω(ε₁S₁ + ε₂S₂) = +i*k0*c*(ε₁S₁ + ε₂S₂)
#
# But wait — the fields in the paper are E and Z0*H (Sec. 4.1),
# so the actual matrix uses k0 instead of ω directly. Let me check...
# The paper says (p.13): "Instead of the magnetic field we internally
# use Z0*H, with Z0 being the free space impedance, such that the
# electric field and the scaled magnetic field have the same units."
#
# With u_H = n̂ × (Z0*H) and Z0 = 1/(ε0*c) = μ0*c:
# The coupling terms become:
#   -iω*μ*S → -iω*μ0*S (for E equation, coupling to Z0*H)
#   +iω*ε*S → +iω*ε0*ε_r*S (for H equation, coupling to E)
#
# With Z0 scaling, the factors simplify. In vacuum:
#   -iω*μ0 = -i*k0*Z0 and iω*ε0 = i*k0/Z0
# So A12 = -ik0*Z0*(S1+S2) and A21 = ik0/Z0*(ε1*S1+ε2*S2)
# But with H→Z0*H, the factors become just:
#   A12 = -ik0*(S1+S2) and A21 = ik0*(ε1*S1+ε2*S2)
# since Z0 cancels out.
#
# Final answer: with the Z0*H convention, the coupling is through k0.


def build_retarded_system(
    mesh: BoundaryMesh,
    eps_in: complex,
    eps_out: complex,
    k0: float,
    quad_order: int = 4,
    use_duffy: bool = False,
    n_duffy: int = 4,
    refine_touching: bool = False,
) -> tuple[np.ndarray, dict]:
    """Build the 2n × 2n PMCHWT system matrix.

    Args:
        mesh: boundary mesh
        eps_in: complex permittivity inside particle
        eps_out: real permittivity of medium
        k0: free-space wavenumber 2π/λ (nm⁻¹)
        quad_order: quadrature order for integration

    Returns:
        A: (2n, 2n) complex system matrix
        edges_info: dict from extract_edges (needed for RHS)
    """
    edges_info = extract_edges(mesh)
    n = edges_info["n_edges"]

    # Wavenumbers in each medium
    k_in = k0 * np.sqrt(eps_in + 0j)
    k_out = k0 * np.sqrt(eps_out + 0j)

    # Single and double layer matrices for inside and outside
    S1 = single_layer_matrix(mesh, edges_info, k_in, quad_order, use_duffy, n_duffy, refine_touching)
    S2 = single_layer_matrix(mesh, edges_info, k_out, quad_order, use_duffy, n_duffy, refine_touching)
    D1 = double_layer_matrix(mesh, edges_info, k_in, quad_order)
    D2 = double_layer_matrix(mesh, edges_info, k_out, quad_order)

    # Assemble 2n × 2n block system (Eq. 12 with Z0*H convention)
    A = np.zeros((2 * n, 2 * n), dtype=complex)

    # A11 = A22 = D1 + D2
    D_sum = D1 + D2
    A[:n, :n] = D_sum
    A[n:, n:] = D_sum

    # A12 = -ik0 * (S1 + S2) [μ₁ = μ₂ = 1, with Z0*H convention]
    A[:n, n:] = -1j * k0 * (S1 + S2)

    # A21 = +ik0 * (ε₁*S1 + ε₂*S2)
    A[n:, :n] = 1j * k0 * (eps_in * S1 + eps_out * S2)

    return A, edges_info
