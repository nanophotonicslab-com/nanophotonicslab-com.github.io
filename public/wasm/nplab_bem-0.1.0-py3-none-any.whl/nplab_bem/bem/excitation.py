"""Plane wave excitation for retarded BEM.

Computes the RHS vector q_inc for the PMCHWT system (Eq. 13, B.1):

    [[q^inc_E]]_ν = ∫ f^e_ν(s) · E^inc(s) dS
    [[q^inc_H]]_ν = ∫ f^e_ν(s) · H^inc(s) dS

For a plane wave in medium 2 (outside):
    E^inc(s) = pol * exp(ik₂ · dir · s)
    H^inc(s) = (dir × pol) / Z * exp(ik₂ · dir · s)

With the Z0*H convention (Sec. 4.1), H is scaled so that E and Z0*H
have the same units. The incident H field becomes:
    Z0*H^inc = (dir × pol) * exp(ik₂ · dir · s) × (n_medium)

From Eq. (B.1) of Hohenester, Reichelt & Unger, CPC 276, 108337 (2022):
    e = exp(1i * mat.k(k0) * dot(pos, dir, k)) * pol
    h = mat.Z(k0) * cross(dir, e, k)

where mat.Z is the impedance Z = sqrt(mu/(eps*eps0)) = Z0/n.
With Z0*H convention: Z0*H = Z0 * (1/Z) * (dir × E) = n * (dir × E).

Reference: Hohenester et al., CPC 276, 108337 (2022), Eq. (B.1).
"""

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh
from nplab_bem.mesh.edges import extract_edges
from nplab_bem.mesh.raviart_thomas import evaluate_rt


def planewave_rhs(
    mesh: BoundaryMesh,
    edges_info: dict,
    polarization: np.ndarray,
    direction: np.ndarray,
    k0: float,
    eps_out: float,
    quad_order: int = 4,
) -> np.ndarray:
    """Compute the RHS vector for plane wave excitation.

    Args:
        mesh: boundary mesh
        edges_info: dict from extract_edges()
        polarization: E-field polarization (3,), will be normalized
        direction: propagation direction (3,), will be normalized
        k0: free-space wavenumber (nm⁻¹)
        eps_out: medium permittivity
        quad_order: quadrature order

    Returns:
        q_inc: (2*n_edges,) complex RHS vector [q_E; q_H]
    """
    n_edges = edges_info["n_edges"]
    n_faces = mesh.n_faces
    face_edges = edges_info["face_edges"]

    pol = np.asarray(polarization, dtype=float)
    pol = pol / np.linalg.norm(pol)
    dir_vec = np.asarray(direction, dtype=float)
    dir_vec = dir_vec / np.linalg.norm(dir_vec)

    # Wavenumber in the medium
    n_medium = np.sqrt(eps_out)
    k_out = k0 * n_medium

    # Quadrature
    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    n_quad = quad_pts.shape[1]

    # Evaluate RT basis at quadrature points
    f_vals, _ = evaluate_rt(mesh, edges_info, quad_pts)
    # f_vals: (N_f, 3, N_q, 3)

    # E^inc at quadrature points: pol * exp(ik_out * dir · s)
    # dir · s: (N_f, N_q)
    phase = np.sum(quad_pts * dir_vec[np.newaxis, np.newaxis, :], axis=2)
    exp_phase = np.exp(1j * k_out * phase)  # (N_f, N_q)

    # E^inc(s) = pol * exp(ik_out * dir·s): shape effectively (N_f, N_q, 3)
    E_inc = pol[np.newaxis, np.newaxis, :] * exp_phase[:, :, np.newaxis]

    # Z0*H^inc = n_medium * (dir × pol) * exp(ik_out * dir·s)
    dir_cross_pol = np.cross(dir_vec, pol)
    H_inc = n_medium * dir_cross_pol[np.newaxis, np.newaxis, :] * exp_phase[:, :, np.newaxis]

    # Compute q_E and q_H by integrating f · E_inc and f · H_inc
    q_E = np.zeros(n_edges, dtype=complex)
    q_H = np.zeros(n_edges, dtype=complex)

    for a in range(3):
        # f · E_inc: (N_f, N_q)
        dot_E = np.sum(f_vals[:, a, :, :] * E_inc, axis=2)
        dot_H = np.sum(f_vals[:, a, :, :] * H_inc, axis=2)

        # Integrate: sum over quadrature with weights
        integral_E = np.sum(dot_E * quad_wts, axis=1)  # (N_f,)
        integral_H = np.sum(dot_H * quad_wts, axis=1)  # (N_f,)

        # Accumulate into global DOFs
        for i in range(n_faces):
            nu = face_edges[i, a]
            q_E[nu] += integral_E[i]
            q_H[nu] += integral_H[i]

    return np.concatenate([q_E, q_H])


def dipole_rhs(
    mesh: BoundaryMesh,
    edges_info: dict,
    position: np.ndarray,
    moment: np.ndarray,
    k0: float,
    eps_out: float,
    quad_order: int = 4,
) -> np.ndarray:
    """Compute the RHS vector for electric dipole excitation.

    Incident fields of a point dipole p at r₀ in medium with ε_m:
        E_inc(s) = [(k₂²I + ∇∇) g(s, r₀; k₂)] · p
        Z₀H_inc(s) = -ik₀n_m² [∇g(s, r₀; k₂) × p]

    where g = exp(ik₂R)/(4πR) is the scalar Green's function.

    Args:
        mesh: boundary mesh
        edges_info: dict from extract_edges()
        position: (3,) dipole location r₀ (must be outside mesh)
        moment: (3,) dipole moment vector p
        k0: free-space wavenumber (nm⁻¹)
        eps_out: medium permittivity
        quad_order: quadrature order

    Returns:
        q_inc: (2*n_edges,) complex RHS vector [q_E; q_H]
    """
    n_edges = edges_info["n_edges"]
    n_faces = mesh.n_faces
    face_edges = edges_info["face_edges"]

    r0 = np.asarray(position, dtype=float)
    p = np.asarray(moment, dtype=complex)

    n_m = np.sqrt(eps_out)
    k2 = k0 * n_m

    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    f_vals, _ = evaluate_rt(mesh, edges_info, quad_pts)
    # f_vals: (N_f, 3, N_q, 3)

    # Vector from dipole to each quadrature point: s - r₀
    diff = quad_pts - r0[np.newaxis, np.newaxis, :]  # (N_f, N_q, 3)
    R = np.linalg.norm(diff, axis=2)  # (N_f, N_q)
    R_safe = np.maximum(R, 1e-30)
    Rhat = diff / R_safe[:, :, np.newaxis]  # (N_f, N_q, 3)

    # Scalar Green's function
    g = np.exp(1j * k2 * R) / (4 * np.pi * R_safe)  # (N_f, N_q)

    # Dipole E field: E = g × [A_E p + B_E R̂(R̂·p)]
    # A_E = k₂² + ik₂/R - 1/R²
    # B_E = -k₂² - 3ik₂/R + 3/R²
    A_E = k2**2 + 1j * k2 / R_safe - 1.0 / R_safe**2  # (N_f, N_q)
    B_E = -k2**2 - 3j * k2 / R_safe + 3.0 / R_safe**2

    Rhat_dot_p = np.sum(Rhat * p[np.newaxis, np.newaxis, :], axis=2)  # (N_f, N_q)

    E_inc = (g * A_E)[:, :, np.newaxis] * p[np.newaxis, np.newaxis, :] \
          + (g * B_E * Rhat_dot_p)[:, :, np.newaxis] * Rhat  # (N_f, N_q, 3)

    # Z₀H field: Z₀H = -ik₀n_m² (∇g × p)
    # ∇g = (ik₂ - 1/R) R̂/R × g ... wait, ∇_s g(s,r₀)
    # ∇_s g = (ik₂ - 1/R)(s-r₀)/R × g = (ik₂ - 1/R) R̂ g
    # Note: diff = s - r₀, R̂ = diff/R, so ∇_s g = (ik₂ - 1/R) diff/R × g/1
    # Actually: ∇_s g = (ik₂ - 1/R) R̂ g = (ik₂ - 1/R) diff/(R²) × exp(ik₂R)/(4π)
    # But more simply: ∇_s g = coeff × R̂ × g where coeff = (ik₂ - 1/R)
    grad_g_coeff = (1j * k2 - 1.0 / R_safe) * g  # (N_f, N_q)
    grad_g = grad_g_coeff[:, :, np.newaxis] * Rhat  # (N_f, N_q, 3)

    # Z₀H = -ik₀n_m² (∇g × p)
    H_inc = -1j * k0 * n_m**2 * np.cross(
        grad_g, p[np.newaxis, np.newaxis, :]
    )  # (N_f, N_q, 3)

    # Project onto RT basis
    q_E = np.zeros(n_edges, dtype=complex)
    q_H = np.zeros(n_edges, dtype=complex)

    for a in range(3):
        dot_E = np.sum(f_vals[:, a, :, :] * E_inc, axis=2)  # (N_f, N_q)
        dot_H = np.sum(f_vals[:, a, :, :] * H_inc, axis=2)

        integral_E = np.sum(dot_E * quad_wts, axis=1)  # (N_f,)
        integral_H = np.sum(dot_H * quad_wts, axis=1)

        np.add.at(q_E, face_edges[:, a], integral_E)
        np.add.at(q_H, face_edges[:, a], integral_H)

    return np.concatenate([q_E, q_H])


def ebeam_rhs(
    mesh: BoundaryMesh,
    edges_info: dict,
    beam_position: np.ndarray,
    beam_direction: np.ndarray,
    beta: float,
    k0: float,
    eps_medium: float,
    quad_order: int = 4,
) -> np.ndarray:
    """Compute the RHS vector for electron beam excitation.

    Field of a relativistic electron at velocity v = βc in a medium:
        E = exp(iqz‖) × [A‖ K₀(qₘρ) d̂ + A⊥ K₁(qₘρ) ρ̂]
        Z₀H = H_coeff × K₁(qₘρ) exp(iqz‖) × (d̂ × ρ̂)

    where q = k₀/β, qₘ = k₀√(1/β²-εₘ), K₀/K₁ are modified Bessel
    functions of the second kind.

    Reference: García de Abajo & Howie, PRB 65, 115418 (2002).

    Args:
        mesh: boundary mesh
        edges_info: dict from extract_edges()
        beam_position: (3,) point the beam passes through
        beam_direction: (3,) beam propagation direction
        beta: v/c ratio (0 < β < 1)
        k0: free-space wavenumber (nm⁻¹)
        eps_medium: medium permittivity
        quad_order: quadrature order

    Returns:
        q_inc: (2*n_edges,) complex RHS vector [q_E; q_H]
    """
    from scipy.special import k0 as besselk0, k1 as besselk1

    n_edges = edges_info["n_edges"]
    face_edges = edges_info["face_edges"]

    r_beam = np.asarray(beam_position, dtype=float)
    d_hat = np.asarray(beam_direction, dtype=float)
    d_hat = d_hat / np.linalg.norm(d_hat)

    q = k0 / beta
    qm2 = k0**2 * (1.0 / beta**2 - eps_medium)
    qm = np.sqrt(max(qm2, 0.0))

    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    f_vals, _ = evaluate_rt(mesh, edges_info, quad_pts)

    # Decompose quad points relative to beam
    ds = quad_pts - r_beam[np.newaxis, np.newaxis, :]
    z_par = np.sum(ds * d_hat[np.newaxis, np.newaxis, :], axis=2)
    s_perp = ds - z_par[:, :, np.newaxis] * d_hat[np.newaxis, np.newaxis, :]
    rho = np.linalg.norm(s_perp, axis=2)
    rho_safe = np.maximum(rho, 1e-30)
    rho_hat = s_perp / rho_safe[:, :, np.newaxis]

    # Phase and Bessel functions
    phase = np.exp(1j * q * z_par)
    arg = qm * rho_safe
    K0_val = besselk0(arg)
    K1_val = besselk1(arg)

    # Electric field
    A_par = 1j * qm**2 / q
    E_inc = ((phase * A_par * K0_val)[:, :, np.newaxis] * d_hat[np.newaxis, np.newaxis, :]
           + (phase * qm * K1_val)[:, :, np.newaxis] * rho_hat)

    # Z₀H = coeff × K₁ × phase × (d̂ × ρ̂)
    H_coeff = qm * (2.0 - eps_medium * beta**2) / beta
    cross_dir = np.cross(d_hat[np.newaxis, np.newaxis, :], rho_hat)
    H_inc = (phase * H_coeff * K1_val)[:, :, np.newaxis] * cross_dir

    # Project onto RT basis
    q_E = np.zeros(n_edges, dtype=complex)
    q_H = np.zeros(n_edges, dtype=complex)

    for a in range(3):
        dot_E = np.sum(f_vals[:, a, :, :] * E_inc, axis=2)
        dot_H = np.sum(f_vals[:, a, :, :] * H_inc, axis=2)
        np.add.at(q_E, face_edges[:, a], np.sum(dot_E * quad_wts, axis=1))
        np.add.at(q_H, face_edges[:, a], np.sum(dot_H * quad_wts, axis=1))

    return np.concatenate([q_E, q_H])
