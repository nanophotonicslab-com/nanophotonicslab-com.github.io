"""nplab_bem — Hardware-accelerated Galerkin BEM for nanophotonics.

Quick start:
    import nplab_bem as nb

    mesh = nb.sphere_mesh(radius=25, subdivisions=2)
    result = nb.solve(mesh, nb.gold(530), eps_medium=1.33**2, wavelength=530)
    print(f"C_ext = {result.extinction:.0f} nm²")
"""

# High-level API
from nplab_bem.api import solve, BEMResult

# Mesh creation
from nplab_bem.mesh.shapes import sphere_mesh, rod_mesh

# Materials (wavelength in nm → complex permittivity)
from nplab_bem.material.tabulated import gold_permittivity as gold
from nplab_bem.material.tabulated import silver_permittivity as silver

# Mie theory (analytical reference)
from nplab_bem.mie.sphere import extinction_efficiency, scattering_efficiency

__all__ = [
    "solve",
    "BEMResult",
    "sphere_mesh",
    "rod_mesh",
    "gold",
    "silver",
    "extinction_efficiency",
    "scattering_efficiency",
]
