"""Edge topology extraction for Galerkin BEM with edge elements.

Extracts edges from a triangular mesh and builds the connectivity
data structures needed for Raviart-Thomas basis functions.

Reference: Hohenester et al., CPC 276, 108337 (2022), Sec. 4.4.
"""

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh


def extract_edges(mesh: BoundaryMesh) -> dict:
    """Extract edge connectivity from a triangular boundary mesh.

    For each edge (shared by two triangles in a closed mesh), assigns
    a global degree of freedom index and computes the orientation signs
    needed for Raviart-Thomas basis functions.

    Args:
        mesh: closed triangular boundary mesh

    Returns:
        dict with keys:
            edges: (N_edges, 2) vertex indices per edge (sorted)
            n_edges: int, number of unique edges
            face_edges: (N_faces, 3) global edge index for each local edge
            edge_signs: (N_faces, 3) orientation sign (+1/-1)
            edge_lengths: (N_edges,) length of each edge
            opposite_vertices: (N_faces, 3) vertex index opposite to each
                local edge within each face
    """
    faces = mesh.faces  # (N_f, 3)
    vertices = mesh.vertices  # (N_v, 3)
    n_faces = mesh.n_faces

    # Local edges of a triangle: opposite to vertex 0, 1, 2
    # Edge 0 (opposite v0): v1-v2
    # Edge 1 (opposite v1): v2-v0
    # Edge 2 (opposite v2): v0-v1
    local_edges = np.array([[1, 2], [2, 0], [0, 1]])

    # Build all face-local edges with global vertex indices
    # Shape: (N_faces, 3, 2)
    all_edges = faces[:, local_edges]  # (N_f, 3, 2)

    # Sort vertex indices within each edge for canonical form
    all_edges_sorted = np.sort(all_edges, axis=2)  # (N_f, 3, 2)

    # Flatten to (N_faces*3, 2) for unique detection
    flat_edges = all_edges_sorted.reshape(-1, 2)

    # Find unique edges and inverse mapping
    unique_edges, inverse = np.unique(flat_edges, axis=0, return_inverse=True)
    n_edges = len(unique_edges)

    # face_edges: (N_faces, 3) — global edge index for each local edge
    face_edges = inverse.reshape(n_faces, 3)

    # edge_signs: +1 if face's local edge matches the canonical orientation
    # (i.e., the unsorted edge goes from lower to higher vertex index),
    # -1 if it's reversed.
    # This determines the sign of the RT basis function.
    edge_signs = np.where(
        all_edges[:, :, 0] <= all_edges[:, :, 1],
        +1, -1
    )

    # Edge lengths
    v0 = vertices[unique_edges[:, 0]]
    v1 = vertices[unique_edges[:, 1]]
    edge_lengths = np.linalg.norm(v1 - v0, axis=1)

    # Opposite vertices: for local edge a in face i, the vertex
    # NOT on that edge. By our convention:
    # local edge 0 (v1-v2) -> opposite is v0 = faces[i, 0]
    # local edge 1 (v2-v0) -> opposite is v1 = faces[i, 1]
    # local edge 2 (v0-v1) -> opposite is v2 = faces[i, 2]
    opposite_vertices = faces[:, [0, 1, 2]]  # (N_f, 3), already correct

    return {
        "edges": unique_edges,
        "n_edges": n_edges,
        "face_edges": face_edges,
        "edge_signs": edge_signs,
        "edge_lengths": edge_lengths,
        "opposite_vertices": opposite_vertices,
    }
