"""Raviart-Thomas (RT0) basis functions on triangular elements.

RT0 are edge-based vector basis functions used in Galerkin BEM for
the discretization of tangential electromagnetic fields. Each basis
function is associated with an edge and is nonzero on the two
triangles sharing that edge.

On triangle tau_i, the RT basis for local edge a is:

    f^e_{ia}(s) = sign_{ia} * l_a / (2 * A_i) * (s - v_a^{opp})

where l_a is the edge length, A_i the triangle area, v_a^{opp} the
vertex opposite to edge a, and sign_{ia} encodes the orientation.

The divergence is constant:
    div(f^e_{ia}) = sign_{ia} * l_a / A_i

Reference: Hohenester et al., CPC 276, 108337 (2022), Sec. 4.4, Fig. 5.
"""

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh


def evaluate_rt(
    mesh: BoundaryMesh,
    edges_info: dict,
    quad_points: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Evaluate RT0 basis functions at quadrature points.

    Args:
        mesh: boundary mesh
        edges_info: dict from extract_edges()
        quad_points: (N_faces, N_quad, 3) quadrature points in 3D

    Returns:
        f_values: (N_faces, 3, N_quad, 3) RT vector values
            [face, local_edge, quad_point, xyz]
        div_f: (N_faces, 3) divergence (constant per element)
    """
    n_faces = mesh.n_faces
    n_quad = quad_points.shape[1]
    vertices = mesh.vertices
    areas = mesh.face_areas

    face_edges = edges_info["face_edges"]  # (N_f, 3)
    edge_signs = edges_info["edge_signs"]  # (N_f, 3)
    edge_lengths = edges_info["edge_lengths"]  # (N_e,)
    opp_verts = edges_info["opposite_vertices"]  # (N_f, 3)

    f_values = np.zeros((n_faces, 3, n_quad, 3))
    div_f = np.zeros((n_faces, 3))

    for a in range(3):  # local edge index
        # Global edge indices for this local edge across all faces
        global_edges = face_edges[:, a]  # (N_f,)
        l_a = edge_lengths[global_edges]  # (N_f,)
        s_a = edge_signs[:, a]  # (N_f,)
        v_opp = vertices[opp_verts[:, a]]  # (N_f, 3)

        # Prefactor: sign * l_a / (2 * A_i)
        prefactor = s_a * l_a / (2.0 * areas)  # (N_f,)

        # f_{ia}(s) = prefactor * (s - v_opp)
        # quad_points: (N_f, N_q, 3), v_opp: (N_f, 3)
        diff = quad_points - v_opp[:, np.newaxis, :]  # (N_f, N_q, 3)
        f_values[:, a, :, :] = prefactor[:, np.newaxis, np.newaxis] * diff

        # div(f) = sign * l_a / A_i (constant, = 2 * prefactor since 2D div)
        div_f[:, a] = s_a * l_a / areas

    return f_values, div_f


def evaluate_rt_at_points(
    mesh: BoundaryMesh,
    edges_info: dict,
    face_idx: int,
    local_edge: int,
    points: np.ndarray,
) -> np.ndarray:
    """Evaluate a single RT basis function at arbitrary points.

    Args:
        mesh: boundary mesh
        edges_info: dict from extract_edges()
        face_idx: triangle index
        local_edge: local edge index (0, 1, or 2)
        points: (N_pts, 3) evaluation points

    Returns:
        f_values: (N_pts, 3) RT vector at each point
    """
    global_edge = edges_info["face_edges"][face_idx, local_edge]
    l_a = edges_info["edge_lengths"][global_edge]
    sign = edges_info["edge_signs"][face_idx, local_edge]
    v_opp = mesh.vertices[edges_info["opposite_vertices"][face_idx, local_edge]]
    area = mesh.face_areas[face_idx]

    prefactor = sign * l_a / (2.0 * area)
    return prefactor * (points - v_opp[np.newaxis, :])
