"""High-level API for nplab_bem BEM solver.

Usage:
    import nplab_bem as nb

    mesh = nb.sphere_mesh(radius=25, subdivisions=2)
    result = nb.solve(mesh, nb.gold(530), eps_medium=1.33**2, wavelength=530)

    result.extinction   # C_ext in nm²
    result.scattering   # C_sca in nm²
    result.absorption   # C_abs in nm²

    E = result.scattered_field(obs_points)
    fp = result.purcell(position=[30, 0, 0], moment=[1, 0, 0])
"""

from dataclasses import dataclass

import numpy as np

from nplab_bem.mesh.boundary import BoundaryMesh


@dataclass
class BEMResult:
    """Result from a retarded BEM solve at a single wavelength.

    Contains cross-sections and internal state for post-processing
    (near-field, Purcell factor, EELS) without re-solving the system.
    """

    wavelength: float
    """Wavelength in nm."""

    extinction: float
    """Extinction cross-section C_ext (nm²)."""

    scattering: float
    """Scattering cross-section C_sca (nm²)."""

    absorption: float
    """Absorption cross-section C_abs = C_ext - C_sca (nm²)."""

    # Internal state (not part of the public interface)
    _mesh: BoundaryMesh
    _edges_info: dict
    _solutions: list  # [(pol, u_E, u_H), ...] per polarization
    _k0: float
    _eps_medium: float
    _quad_order: int

    def scattered_field(self, obs_points: np.ndarray, pol_index: int = 0) -> np.ndarray:
        """Evaluate scattered E field at observation points.

        Args:
            obs_points: (N, 3) observation points in nm
            pol_index: 0 for x-polarization, 1 for y-polarization

        Returns:
            E_sca: (N, 3) complex scattered electric field
        """
        from nplab_bem.bem.nearfield import scattered_field

        _, u_E, u_H = self._solutions[pol_index]
        return scattered_field(
            self._mesh, self._edges_info, u_E, u_H,
            np.asarray(obs_points), self._k0, self._eps_medium,
            self._quad_order,
        )

    def surface_fields(
        self, pol_index: int = 0, offset: float = 1.0,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Compute total E field and enhancement at face centroids.

        Args:
            pol_index: 0 for x-polarization, 1 for y-polarization
            offset: distance (nm) outward from surface

        Returns:
            E_total: (N_faces, 3) complex total electric field
            enhancement: (N_faces,) field enhancement |E|/|E₀|
        """
        from nplab_bem.bem.nearfield import surface_fields as _surface_fields

        pol, u_E, u_H = self._solutions[pol_index]
        direction = np.array([0.0, 0.0, 1.0])
        return _surface_fields(
            self._mesh, self._edges_info, u_E, u_H,
            self._k0, self._eps_medium, pol, direction,
            offset, self._quad_order,
        )

    def purcell(
        self,
        position: np.ndarray,
        moment: np.ndarray,
        eps_particle: complex | None = None,
    ) -> float:
        """Compute Purcell factor for a dipole near the particle.

        Solves a NEW system (dipole excitation) but reuses the mesh.

        Args:
            position: (3,) dipole location in nm
            moment: (3,) dipole moment direction
            eps_particle: particle permittivity (required on first call)

        Returns:
            F_P: Purcell enhancement factor
        """
        from nplab_bem.bem.solver import purcell_factor

        if eps_particle is None:
            raise ValueError("eps_particle required for Purcell computation")

        return purcell_factor(
            self._mesh, eps_particle, self._eps_medium, self._k0,
            np.asarray(position, dtype=float),
            np.asarray(moment, dtype=float),
            self._quad_order,
        )


def solve(
    mesh: BoundaryMesh,
    eps_particle: complex,
    eps_medium: float,
    wavelength: float,
    quad_order: int = 4,
    n_theta: int = 10,
    n_phi: int = 20,
) -> BEMResult:
    """Solve the retarded BEM for a nanoparticle at a single wavelength.

    Builds the PMCHWT system, solves for two orthogonal polarizations,
    and computes extinction, scattering, and absorption cross-sections.

    Args:
        mesh: boundary mesh (from sphere_mesh, rod_mesh, etc.)
        eps_particle: complex permittivity of the particle
        eps_medium: real permittivity of the surrounding medium
        wavelength: wavelength in nm
        quad_order: quadrature order for surface integrals
        n_theta, n_phi: angular quadrature for scattering integration

    Returns:
        BEMResult with cross-sections and methods for post-processing
    """
    from nplab_bem.bem.assembly_retarded import build_retarded_system
    from nplab_bem.bem.excitation import planewave_rhs
    from nplab_bem.bem.solver import scattering_cross_section_retarded
    from nplab_bem.mesh.raviart_thomas import evaluate_rt

    k0 = 2 * np.pi / wavelength
    n_medium = np.sqrt(eps_medium + 0j)
    k_out = k0 * np.real(n_medium)

    # Build system matrix (shared across polarizations)
    A, edges_info = build_retarded_system(
        mesh, eps_particle, eps_medium, k0, quad_order,
        use_duffy=True, n_duffy=4, refine_touching=False,
    )
    n = edges_info["n_edges"]

    direction = np.array([0.0, 0.0, 1.0])
    polarizations = [
        np.array([1.0, 0.0, 0.0]),
        np.array([0.0, 1.0, 0.0]),
    ]

    # Quadrature data for far-field projections
    quad_pts, quad_wts = mesh.quadrature(order=quad_order)
    f_vals, _ = evaluate_rt(mesh, edges_info, quad_pts)
    face_edges = edges_info["face_edges"]

    # Solve for each polarization
    solutions = []
    c_ext_total = 0.0

    for pol in polarizations:
        q_inc = planewave_rhs(
            mesh, edges_info, pol, direction, k0, eps_medium, quad_order)
        u = np.linalg.solve(A, q_inc)
        u_E, u_H = u[:n], u[n:]
        solutions.append((pol, u_E, u_H))

        # Extinction via optical theorem (forward far field)
        F = np.zeros((n, 3), dtype=complex)
        for a in range(3):
            for iq in range(quad_pts.shape[1]):
                phase = np.exp(-1j * k_out * quad_pts[:, iq, :] @ direction)
                F_contrib = quad_wts[:, iq, np.newaxis] * f_vals[:, a, iq, :] * phase[:, np.newaxis]
                np.add.at(F, face_edges[:, a], F_contrib)

        V_H = np.sum(u_H[:, None] * F, axis=0)
        V_E = np.sum(u_E[:, None] * F, axis=0)
        SL_far = 1j * k0 / (4 * np.pi) * V_H
        DL_far = 1j * k_out / (4 * np.pi) * np.cross(direction, V_E)
        c_ext_total += 4 * np.pi / k_out * np.imag(np.dot(pol, SL_far + DL_far))

    c_ext = c_ext_total / 2.0

    # Scattering (reuses existing function but with pre-built system)
    c_sca = scattering_cross_section_retarded(
        mesh, eps_particle, eps_medium, k0, quad_order, n_theta, n_phi)

    return BEMResult(
        wavelength=wavelength,
        extinction=float(c_ext),
        scattering=float(c_sca),
        absorption=float(c_ext - c_sca),
        _mesh=mesh,
        _edges_info=edges_info,
        _solutions=solutions,
        _k0=k0,
        _eps_medium=eps_medium,
        _quad_order=quad_order,
    )
